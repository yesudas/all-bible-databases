biblename = "Gujarati NT: Easy-To-Read Version, 2005";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"માથ્થીની લખેલી સુવાર્તા",
long:"માથ્થીની લખેલી સુવાર્તા",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"માર્કની લખેલી સુવાર્તા",
long:"માર્કની લખેલી સુવાર્તા",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"લૂકની લખેલી સુવાર્તા",
long:"લૂકની લખેલી સુવાર્તા",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"યોહાનની લખેલી સુવાર્તા",
long:"યોહાનની લખેલી સુવાર્તા",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"પ્રેરિતોનાં કૃત્યો",
long:"પ્રેરિતોનાં કૃત્યો",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"રોમનોને પત્ર",
long:"રોમનોને પત્ર",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"કરિંથીઓને પહેલો પત્ર",
long:"કરિંથીઓને પહેલો પત્ર",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"કરિંથીઓને બીજો પત્ર",
long:"કરિંથીઓને બીજો પત્ર",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ગલાતીઓને પત્ર",
long:"ગલાતીઓને પત્ર",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"એફેસીઓને પત્ર",
long:"એફેસીઓને પત્ર",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ફિલિપ્પીઓને પત્ર",
long:"ફિલિપ્પીઓને પત્ર",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"કલોસ્સીઓને પત્ર",
long:"કલોસ્સીઓને પત્ર",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"થેસ્સલોનિકીઓને પહેલો પત્ર",
long:"થેસ્સલોનિકીઓને પહેલો પત્ર",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"થેસ્સલોનિકીઓને બીજો પત્ર",
long:"થેસ્સલોનિકીઓને બીજો પત્ર",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"તિમોથીને પહેલો પત્ર",
long:"તિમોથીને પહેલો પત્ર",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"તિમોથીને બીજો પત્ર",
long:"તિમોથીને બીજો પત્ર",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"તિતસને પત્ર",
long:"તિતસને પત્ર",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ફિલેમોનને પત્ર",
long:"ફિલેમોનને પત્ર",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"હિબ્રૂઓને પત્ર",
long:"હિબ્રૂઓને પત્ર",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"યાકૂબનો પત્ર",
long:"યાકૂબનો પત્ર",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"પિતરનો પહેલો પત્ર",
long:"પિતરનો પહેલો પત્ર",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"પિતરનો બીજો પત્ર",
long:"પિતરનો બીજો પત્ર",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"યોહાનનો પહેલો પત્ર",
long:"યોહાનનો પહેલો પત્ર",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"યોહાનનો બીજો પત્ર",
long:"યોહાનનો બીજો પત્ર",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"યોહાનનો ત્રીજો પત્ર",
long:"યોહાનનો ત્રીજો પત્ર",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"યહૂદાનો પત્ર",
long:"યહૂદાનો પત્ર",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"પ્રકટીકરણ",
long:"પ્રકટીકરણ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
