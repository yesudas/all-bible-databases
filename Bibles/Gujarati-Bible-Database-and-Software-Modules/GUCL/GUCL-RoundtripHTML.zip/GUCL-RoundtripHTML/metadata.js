biblename = "પવિત્ર બાઇબલ C.L.";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"ઉત્પત્તિ",
long:"ઉત્પત્તિ",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"નિર્ગમન",
long:"નિર્ગમન",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"લેવીય",
long:"લેવીય",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"ગણના",
long:"ગણના",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"પુનર્નિયમ",
long:"પુનર્નિયમ",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"યહોશુઆનું પુસ્તક",
long:"યહોશુઆનું પુસ્તક",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"ન્યાયાધીશોનું પુસ્તક",
long:"ન્યાયાધીશોનું પુસ્તક",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"રૂથનું પુસ્તક",
long:"રૂથનું પુસ્તક",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"શમુએલનું પહેલું પુસ્તક",
long:"શમુએલનું પહેલું પુસ્તક",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"શમુએલનું બીજું પુસ્તક",
long:"શમુએલનું બીજું પુસ્તક",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"રાજાઓનું પહેલું પુસ્તક",
long:"રાજાઓનું પહેલું પુસ્તક",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"રાજાઓનું બીજું પુસ્તક",
long:"રાજાઓનું બીજું પુસ્તક",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"કાળવૃત્તાંતનું પહેલું પુસ્તક",
long:"કાળવૃત્તાંતનું પહેલું પુસ્તક",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"કાળવૃત્તાંતનું બીજું પુસ્તક",
long:"કાળવૃત્તાંતનું બીજું પુસ્તક",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"એઝરા",
long:"એઝરા",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"નહેમ્યા",
long:"નહેમ્યા",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"એસ્તેર",
long:"એસ્તેર",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"યોબ",
long:"યોબ",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"ગીતશાસ્ત્ર",
long:"ગીતશાસ્ત્ર",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"સુભાષિતસંગ્રહ",
long:"સુભાષિતસંગ્રહ",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"સભાશિક્ષક અથવા ઉપદેશક",
long:"સભાશિક્ષક અથવા ઉપદેશક",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"ગીતોનું ગીત",
long:"ગીતોનું ગીત",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"યશાયા",
long:"યશાયા",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"યર્મિયા",
long:"યર્મિયા",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"યર્મિયાનો વિલાપ",
long:"યર્મિયાનો વિલાપ",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"હઝકિયેલ",
long:"હઝકિયેલ",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"દાનિયેલ",
long:"દાનિયેલ",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"હોશિયા",
long:"હોશિયા",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"યોએલ",
long:"યોએલ",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"આમોસ",
long:"આમોસ",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"ઓબાદ્યા",
long:"ઓબાદ્યા",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"યોના",
long:"યોના",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"મિખા",
long:"મિખા",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"નાહૂમ",
long:"નાહૂમ",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"હબાક્કુક",
long:"હબાક્કુક",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"સફાન્યા",
long:"સફાન્યા",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"હાગ્ગાય",
long:"હાગ્ગાય",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"ઝખાર્યા",
long:"ઝખાર્યા",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"માલાખી",
long:"માલાખી",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"માથ્થી આલેખિત શુભસંદેશ",
long:"માથ્થી આલેખિત શુભસંદેશ",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"માર્ક આલેખિત શુભસંદેશ",
long:"માર્ક આલેખિત શુભસંદેશ",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"લૂક આલેખિત શુભસંદેશ",
long:"લૂક આલેખિત શુભસંદેશ",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"યોહાન આલેખિત શુભસંદેશ",
long:"યોહાન આલેખિત શુભસંદેશ",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"પ્રેષિતોનાં કાર્યો",
long:"પ્રેષિતોનાં કાર્યો",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"રોમનોને પત્ર",
long:"રોમનોને પત્ર",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"કોરીંથીઓને પહેલો પત્ર",
long:"કોરીંથીઓને પહેલો પત્ર",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"કોરીંથીઓને બીજો પત્ર",
long:"કોરીંથીઓને બીજો પત્ર",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ગલાતીઓને પત્ર",
long:"ગલાતીઓને પત્ર",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"એફેસીઓને પત્ર",
long:"એફેસીઓને પત્ર",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ફિલિપીઓને પત્ર",
long:"ફિલિપીઓને પત્ર",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"કોલોસીઓને પત્ર",
long:"કોલોસીઓને પત્ર",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"થેસ્સાલોનિકિઓને પહેલો પત્ર",
long:"થેસ્સાલોનિકિઓને પહેલો પત્ર",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"થેસ્સાલોનિકિઓને બીજો પત્ર",
long:"થેસ્સાલોનિકિઓને બીજો પત્ર",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"તિમોથીને પહેલો પત્ર",
long:"તિમોથીને પહેલો પત્ર",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"તિમોથીને બીજો પત્ર",
long:"તિમોથીને બીજો પત્ર",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"તિતસને પત્ર",
long:"તિતસને પત્ર",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ફિલેમોનને પત્ર",
long:"ફિલેમોનને પત્ર",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"હિબ્રૂઓને પત્ર",
long:"હિબ્રૂઓને પત્ર",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"યાકોબનો પત્ર",
long:"યાકોબનો પત્ર",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"પિતરનો પહેલો પત્ર",
long:"પિતરનો પહેલો પત્ર",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"પિતરનો બીજો પત્ર",
long:"પિતરનો બીજો પત્ર",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"યોહાનનો પહેલો પત્ર",
long:"યોહાનનો પહેલો પત્ર",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"યોહાનનો બીજો પત્ર",
long:"યોહાનનો બીજો પત્ર",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"યોહાનનો ત્રીજો પત્ર",
long:"યોહાનનો ત્રીજો પત્ર",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"યહૂદાનો પત્ર",
long:"યહૂદાનો પત્ર",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"સંદર્શન",
long:"સંદર્શન",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
