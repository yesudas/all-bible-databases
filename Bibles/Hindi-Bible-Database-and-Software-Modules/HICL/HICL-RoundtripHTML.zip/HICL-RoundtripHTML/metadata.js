biblename = "पवित्र बाइबिल CL (BSI)";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"उत्‍पत्ति",
long:"उत्‍पत्ति",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"निर्गमन",
long:"निर्गमन",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"लेवीय व्‍यवस्‍था",
long:"लेवीय व्‍यवस्‍था",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"जन-गणना ग्रंथ",
long:"जन-गणना ग्रंथ",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"व्‍यवस्‍था-विवरण",
long:"व्‍यवस्‍था-विवरण",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"यहोशुअ",
long:"यहोशुअ",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"शासक ग्रंथ",
long:"शासक ग्रंथ",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"रूत",
long:"रूत",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"शमूएल : पहला भाग",
long:"शमूएल : पहला भाग",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"शमूएल : दूसरा भाग",
long:"शमूएल : दूसरा भाग",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"राजाओं का वृत्तांत : पहला भाग",
long:"राजाओं का वृत्तांत : पहला भाग",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"राजाओं का वृत्तांत : दूसरा भाग",
long:"राजाओं का वृत्तांत : दूसरा भाग",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"इतिहास : पहला भाग",
long:"इतिहास : पहला भाग",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"इतिहास : दूसरा भाग",
long:"इतिहास : दूसरा भाग",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"एज्रा",
long:"एज्रा",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"नहेम्‍याह",
long:"नहेम्‍याह",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"एस्‍तर",
long:"एस्‍तर",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"अय्‍यूब",
long:"अय्‍यूब",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"भजन संहिता",
long:"भजन संहिता",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"नीतिवचन",
long:"नीतिवचन",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"सभा-उपदेशक",
long:"सभा-उपदेशक",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"श्रेष्‍ठ गीत (सुलेमान का श्रेष्‍ठ गीत)",
long:"श्रेष्‍ठ गीत (सुलेमान का श्रेष्‍ठ गीत)",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"नबी यशायाह का ग्रंथ",
long:"नबी यशायाह का ग्रंथ",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"नबी यिर्मयाह का ग्रंथ",
long:"नबी यिर्मयाह का ग्रंथ",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"शोक-गीत",
long:"शोक-गीत",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"नबी यहेजकेल का ग्रंथ",
long:"नबी यहेजकेल का ग्रंथ",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"नबी दानिएल का ग्रंथ",
long:"नबी दानिएल का ग्रंथ",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"नबी होशे",
long:"नबी होशे",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"नबी योएल",
long:"नबी योएल",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"नबी आमोस",
long:"नबी आमोस",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"नबी ओबद्याह",
long:"नबी ओबद्याह",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"नबी योना",
long:"नबी योना",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"नबी मीका",
long:"नबी मीका",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"नबी नहूम",
long:"नबी नहूम",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"नबी हबक्‍कूक",
long:"नबी हबक्‍कूक",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"नबी सफन्‍याह",
long:"नबी सफन्‍याह",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"नबी हग्‍गय",
long:"नबी हग्‍गय",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"नबी जकर्याह",
long:"नबी जकर्याह",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"नबी मलाकी",
long:"नबी मलाकी",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"संत मत्ती के अनुसार शुभ समाचार",
long:"संत मत्ती के अनुसार शुभ समाचार",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"संत मारकुस [मरकुस] के अनुसार शुभ समाचार",
long:"संत मारकुस [मरकुस] के अनुसार शुभ समाचार",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"सन्‍त लूकस [लूक] के अनुसार शुभ समाचार",
long:"सन्‍त लूकस [लूक] के अनुसार शुभ समाचार",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"संत योहन [यूहन्ना] के अनुसार शुभ समाचार",
long:"संत योहन [यूहन्ना] के अनुसार शुभ समाचार",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"प्रेरितों के कार्य-कलाप",
long:"प्रेरितों के कार्य-कलाप",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"रोम नगर की कलीसिया के नाम संत पौलुस का पत्र",
long:"रोम नगर की कलीसिया के नाम संत पौलुस का पत्र",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"कुरिन्‍थुस नगर की कलीसिया के नाम संत पौलुस का पहला पत्र",
long:"कुरिन्‍थुस नगर की कलीसिया के नाम संत पौलुस का पहला पत्र",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"कुरिन्‍थुस नगर की कलीसिया के नाम संत पौलुस का दूसरा पत्र",
long:"कुरिन्‍थुस नगर की कलीसिया के नाम संत पौलुस का दूसरा पत्र",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"गलातिया प्रदेश की कलीसियाओं के नाम संत पौलुस का पत्र",
long:"गलातिया प्रदेश की कलीसियाओं के नाम संत पौलुस का पत्र",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"इफिसुस नगर की कलीसिया के नाम संत पौलुस का पत्र",
long:"इफिसुस नगर की कलीसिया के नाम संत पौलुस का पत्र",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"फिलिप्‍पी नगर की कलीसिया के नाम संत पौलुस का पत्र",
long:"फिलिप्‍पी नगर की कलीसिया के नाम संत पौलुस का पत्र",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"कुलुस्‍से नगर की कलीसिया के नाम संत पौलुस का पत्र",
long:"कुलुस्‍से नगर की कलीसिया के नाम संत पौलुस का पत्र",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"थिस्‍सलुनीके नगर की कलीसिया के नाम संत पौलुस का पहला पत्र",
long:"थिस्‍सलुनीके नगर की कलीसिया के नाम संत पौलुस का पहला पत्र",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"थिस्‍सलुनीके नगर की कलीसिया के नाम संत पौलुस का दूसरा पत्र",
long:"थिस्‍सलुनीके नगर की कलीसिया के नाम संत पौलुस का दूसरा पत्र",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"तिमोथी के नाम संत पौलुस का पहला पत्र",
long:"तिमोथी के नाम संत पौलुस का पहला पत्र",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"तिमोथी के नाम संत पौलुस का दूसरा पत्र",
long:"तिमोथी के नाम संत पौलुस का दूसरा पत्र",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"तीतुस के नाम संत पौलुस का पत्र",
long:"तीतुस के नाम संत पौलुस का पत्र",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"फिलेमोन के नाम संत पौलुस का पत्र",
long:"फिलेमोन के नाम संत पौलुस का पत्र",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"इब्रानियों के नाम पत्र",
long:"इब्रानियों के नाम पत्र",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"संत याकूब का पत्र",
long:"संत याकूब का पत्र",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"संत पतरस का पहला पत्र",
long:"संत पतरस का पहला पत्र",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"संत पतरस का दूसरा पत्र",
long:"संत पतरस का दूसरा पत्र",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"संत योहन का पहला पत्र",
long:"संत योहन का पहला पत्र",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"संत योहन का दूसरा पत्र",
long:"संत योहन का दूसरा पत्र",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"संत योहन का तीसरा पत्र",
long:"संत योहन का तीसरा पत्र",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"संत यहूदा का पत्र",
long:"संत यहूदा का पत्र",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"प्रकाशन ग्रन्‍थ",
long:"प्रकाशन ग्रन्‍थ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
