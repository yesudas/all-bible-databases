biblename = "Saral Hindi Bible";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"मत्तियाह द्वारा लिखा गया ईश्वरीय सुसमाचार",
long:"मत्तियाह द्वारा लिखा गया ईश्वरीय सुसमाचार",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"मारकास द्वारा लिखा हुआ ईश्वरीय सुसमाचार",
long:"मारकास द्वारा लिखा हुआ ईश्वरीय सुसमाचार",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"लूकॉस द्वारा लिखा गया ईश्वरीय सुसमाचार",
long:"लूकॉस द्वारा लिखा गया ईश्वरीय सुसमाचार",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"योहन द्वारा लिखा गया ईश्वरीय सुसमाचार",
long:"योहन द्वारा लिखा गया ईश्वरीय सुसमाचार",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"प्रेरितों के काम",
long:"प्रेरितों के काम",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"रोमियों के नाम पौलॉस प्रेरित का पत्र",
long:"रोमियों के नाम पौलॉस प्रेरित का पत्र",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"1 कोरिन्थॉस",
long:"1 कोरिन्थॉस",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"2 कोरिन्थॉस",
long:"2 कोरिन्थॉस",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"गलातिया",
long:"गलातिया",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"इफ़ेसॉस",
long:"इफ़ेसॉस",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"फ़िलिप्पॉय",
long:"फ़िलिप्पॉय",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"कोलोस्सॉय",
long:"कोलोस्सॉय",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"1 थेस्सलोनिकेयुस",
long:"1 थेस्सलोनिकेयुस",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"2 थेस्सलोनिकेयुस",
long:"2 थेस्सलोनिकेयुस",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"1 तिमोथियॉस",
long:"1 तिमोथियॉस",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"2 तिमोथियॉस",
long:"2 तिमोथियॉस",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"तीतॉस",
long:"तीतॉस",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"फ़िलेमोन",
long:"फ़िलेमोन",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"इब्री",
long:"इब्री",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"याक़ोब",
long:"याक़ोब",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"1 पेतरॉस",
long:"1 पेतरॉस",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"2 पेतरॉस",
long:"2 पेतरॉस",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"1 योहन",
long:"1 योहन",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"2 योहन",
long:"2 योहन",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"3 योहन",
long:"3 योहन",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"यहूदाह",
long:"यहूदाह",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"प्रकाशन",
long:"प्रकाशन",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
