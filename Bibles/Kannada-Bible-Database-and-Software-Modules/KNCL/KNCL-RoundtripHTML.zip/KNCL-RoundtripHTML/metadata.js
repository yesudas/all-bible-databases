biblename = "ಕನ್ನಡ ಸತ್ಯವೇದವು C.L. (BSI)";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"ಆದಿಕಾಂಡ",
long:"ಆದಿಕಾಂಡ",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"ವಿಮೋಚನಕಾಂಡ",
long:"ವಿಮೋಚನಕಾಂಡ",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"ಯಾಜಕಕಾಂಡ",
long:"ಯಾಜಕಕಾಂಡ",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"ಸಂಖ್ಯಾಕಾಂಡ",
long:"ಸಂಖ್ಯಾಕಾಂಡ",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"ಧರ್ಮೋಪದೇಶಕಾಂಡ",
long:"ಧರ್ಮೋಪದೇಶಕಾಂಡ",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"ಯೆಹೋಶುವ",
long:"ಯೆಹೋಶುವ",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"ನ್ಯಾಯಸ್ಥಾಪಕರು",
long:"ನ್ಯಾಯಸ್ಥಾಪಕರು",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"ರೂತಳು",
long:"ರೂತಳು",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"ಸಮುವೇಲನು ಪ್ರಥಮ ಭಾಗ",
long:"ಸಮುವೇಲನು ಪ್ರಥಮ ಭಾಗ",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"ಸಮುವೇಲನು ದ್ವಿತೀಯ ಭಾಗ",
long:"ಸಮುವೇಲನು ದ್ವಿತೀಯ ಭಾಗ",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"ಅರಸುಗಳು ಪ್ರಥಮ ಭಾಗ",
long:"ಅರಸುಗಳು ಪ್ರಥಮ ಭಾಗ",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"ಅರಸುಗಳು ದ್ವಿತೀಯ ಭಾಗ",
long:"ಅರಸುಗಳು ದ್ವಿತೀಯ ಭಾಗ",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"ಪೂರ್ವಕಾಲದ ಇತಿಹಾಸ (ಪೂರ್ವಕಾಲದ ವೃತ್ತಾಂತ) ಪ್ರಥಮ ಭಾಗ",
long:"ಪೂರ್ವಕಾಲದ ಇತಿಹಾಸ (ಪೂರ್ವಕಾಲದ ವೃತ್ತಾಂತ) ಪ್ರಥಮ ಭಾಗ",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"ಪೂರ್ವಕಾಲದ ಇತಿಹಾಸ (ಪೂರ್ವಕಾಲದ ವೃತ್ತಾಂತಗಳು) ದ್ವಿತೀಯ ಭಾಗ",
long:"ಪೂರ್ವಕಾಲದ ಇತಿಹಾಸ (ಪೂರ್ವಕಾಲದ ವೃತ್ತಾಂತಗಳು) ದ್ವಿತೀಯ ಭಾಗ",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"ಎಜ್ರನು",
long:"ಎಜ್ರನು",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"ನೆಹೆಮೀಯ",
long:"ನೆಹೆಮೀಯ",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"ಎಸ್ತೇರಳು",
long:"ಎಸ್ತೇರಳು",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"ಯೋಬನು ಗ್ರಂಥ",
long:"ಯೋಬನು ಗ್ರಂಥ",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"ಕೀರ್ತನೆಗಳು",
long:"ಕೀರ್ತನೆಗಳು",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"ಜ್ಞಾನೋಕ್ತಿಗಳು",
long:"ಜ್ಞಾನೋಕ್ತಿಗಳು",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"ಉಪದೇಶಕನ ಗ್ರಂಥ ಪ್ರಸಂಗಿ",
long:"ಉಪದೇಶಕನ ಗ್ರಂಥ ಪ್ರಸಂಗಿ",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"ಪರಮಗೀತೆ",
long:"ಪರಮಗೀತೆ",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"ಪ್ರವಾದಿ ಯೆಶಾಯನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಯೆಶಾಯನ ಗ್ರಂಥ",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"ಪ್ರವಾದಿ ಯೆರೆಮೀಯನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಯೆರೆಮೀಯನ ಗ್ರಂಥ",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"ಪ್ರಲಾಪಗಳು",
long:"ಪ್ರಲಾಪಗಳು",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"ಪ್ರವಾದಿ ಯೆಜೆಕಿಯೇಲನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಯೆಜೆಕಿಯೇಲನ ಗ್ರಂಥ",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"ಪ್ರವಾದಿ ದಾನಿಯೇಲನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ದಾನಿಯೇಲನ ಗ್ರಂಥ",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"ಪ್ರವಾದಿ ಹೋಶೇಯನ ಗ್ರಂಥ ಹನ್ನೆರಡು ಮಂದಿ ಕಿರಿಯ ಪ್ರವಾದಿಗಳು",
long:"ಪ್ರವಾದಿ ಹೋಶೇಯನ ಗ್ರಂಥ ಹನ್ನೆರಡು ಮಂದಿ ಕಿರಿಯ ಪ್ರವಾದಿಗಳು",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"ಪ್ರವಾದಿ ಯೀವೇಲನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಯೀವೇಲನ ಗ್ರಂಥ",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"ಪ್ರವಾದಿ ಆಮೋಸನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಆಮೋಸನ ಗ್ರಂಥ",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"ಪ್ರವಾದಿ ಓಬದ್ಯನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಓಬದ್ಯನ ಗ್ರಂಥ",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"ಪ್ರವಾದಿ ಯೋನನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಯೋನನ ಗ್ರಂಥ",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"ಪ್ರವಾದಿ ಮೀಕನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಮೀಕನ ಗ್ರಂಥ",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"ಪ್ರವಾದಿ ನಹೂಮನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ನಹೂಮನ ಗ್ರಂಥ",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"ಪ್ರವಾದಿ ಹಬಕ್ಕೂಕನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಹಬಕ್ಕೂಕನ ಗ್ರಂಥ",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"ಪ್ರವಾದಿ ಜೆಫನ್ಯನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಜೆಫನ್ಯನ ಗ್ರಂಥ",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"ಪ್ರವಾದಿ ಹಗ್ಗಾಯನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಹಗ್ಗಾಯನ ಗ್ರಂಥ",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"ಪ್ರವಾದಿ ಜೆಕರ್ಯನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಜೆಕರ್ಯನ ಗ್ರಂಥ",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"ಪ್ರವಾದಿ ಮಲಾಕಿಯನ ಗ್ರಂಥ",
long:"ಪ್ರವಾದಿ ಮಲಾಕಿಯನ ಗ್ರಂಥ",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"ಮತ್ತಾಯನು ಬರೆದ ಶುಭಸಂದೇಶ",
long:"ಮತ್ತಾಯನು ಬರೆದ ಶುಭಸಂದೇಶ",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"ಮಾರ್ಕನು ಬರೆದ ಶುಭಸಂದೇಶ",
long:"ಮಾರ್ಕನು ಬರೆದ ಶುಭಸಂದೇಶ",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ಲೂಕನು ಬರೆದ ಶುಭಸಂದೇಶ",
long:"ಲೂಕನು ಬರೆದ ಶುಭಸಂದೇಶ",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"ಯೊವಾನ್ನನು ಬರೆದ ಶುಭಸಂದೇಶ",
long:"ಯೊವಾನ್ನನು ಬರೆದ ಶುಭಸಂದೇಶ",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"ಪ್ರೇಷಿತರ ಕಾರ್ಯಕಲಾಪಗಳು",
long:"ಪ್ರೇಷಿತರ ಕಾರ್ಯಕಲಾಪಗಳು",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"ಪೌಲನು ರೋಮನರಿಗೆ ಬರೆದ ಪತ್ರ",
long:"ಪೌಲನು ರೋಮನರಿಗೆ ಬರೆದ ಪತ್ರ",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"ಪೌಲನು ಕೊರಿಂಥಿಯರಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
long:"ಪೌಲನು ಕೊರಿಂಥಿಯರಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"ಪೌಲನು ಕೊರಿಂಥಿಯರಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
long:"ಪೌಲನು ಕೊರಿಂಥಿಯರಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ಪೌಲನು ಗಲಾತ್ಯರಿಗೆ ಬರೆದ ಪತ್ರ",
long:"ಪೌಲನು ಗಲಾತ್ಯರಿಗೆ ಬರೆದ ಪತ್ರ",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"ಪೌಲನು ಎಫೆಸಿಯರಿಗೆ ಬರೆದ ಪತ್ರ",
long:"ಪೌಲನು ಎಫೆಸಿಯರಿಗೆ ಬರೆದ ಪತ್ರ",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ಪೌಲನು ಫಿಲಿಪ್ಪಿಯರಿಗೆ ಬರೆದ ಪತ್ರ",
long:"ಪೌಲನು ಫಿಲಿಪ್ಪಿಯರಿಗೆ ಬರೆದ ಪತ್ರ",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"ಪೌಲನು ಕೊಲೊಸ್ಸೆಯರಿಗೆ ಬರೆದ ಪತ್ರ",
long:"ಪೌಲನು ಕೊಲೊಸ್ಸೆಯರಿಗೆ ಬರೆದ ಪತ್ರ",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"ಪೌಲನು ಥೆಸಲೋನಿಯರಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
long:"ಪೌಲನು ಥೆಸಲೋನಿಯರಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"ಪೌಲನು ಥೆಸಲೋನಿಯರಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
long:"ಪೌಲನು ಥೆಸಲೋನಿಯರಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"ಪೌಲನು ತಿಮೊಥೇಯನಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
long:"ಪೌಲನು ತಿಮೊಥೇಯನಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"ಪೌಲನು ತಿಮೊಥೇಯನಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
long:"ಪೌಲನು ತಿಮೊಥೇಯನಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"ಪೌಲನು ತೀತನಿಗೆ ಬರೆದ ಪತ್ರ",
long:"ಪೌಲನು ತೀತನಿಗೆ ಬರೆದ ಪತ್ರ",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ಪೌಲನು ಫಿಲೆಮೋನನಿಗೆ ಬರೆದ ಪತ್ರ",
long:"ಪೌಲನು ಫಿಲೆಮೋನನಿಗೆ ಬರೆದ ಪತ್ರ",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"ಹಿಬ್ರಿಯರಿಗೆ ಬರೆದ ಪತ್ರ",
long:"ಹಿಬ್ರಿಯರಿಗೆ ಬರೆದ ಪತ್ರ",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"ಯಾಕೋಬನು ಬರೆದ ಪತ್ರಿಕೆ",
long:"ಯಾಕೋಬನು ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"ಪೇತ್ರನು ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
long:"ಪೇತ್ರನು ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"ಪೇತ್ರನು ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
long:"ಪೇತ್ರನು ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"ಯೊವಾನ್ನನು ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
long:"ಯೊವಾನ್ನನು ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರ",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"ಯೊವಾನ್ನನು ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
long:"ಯೊವಾನ್ನನು ಬರೆದ ಎರಡನೆಯ ಪತ್ರ",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"ಯೊವಾನ್ನನು ಬರೆದ ಮೂರನೆಯ ಪತ್ರ",
long:"ಯೊವಾನ್ನನು ಬರೆದ ಮೂರನೆಯ ಪತ್ರ",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"ಯೂದನು ಬರೆದ ಪತ್ರ",
long:"ಯೂದನು ಬರೆದ ಪತ್ರ",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"ಯೊವಾನ್ನನು ಕಂಡ ದಿವ್ಯ ದರ್ಶನಗಳ ಪ್ರಕಟನೆ",
long:"ಯೊವಾನ್ನನು ಕಂಡ ದಿವ್ಯ ದರ್ಶನಗಳ ಪ್ರಕಟನೆ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
