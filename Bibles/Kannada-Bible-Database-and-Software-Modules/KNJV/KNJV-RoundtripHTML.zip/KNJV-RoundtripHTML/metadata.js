biblename = "ಕನ್ನಡ ಸತ್ಯವೇದವು J.V. (BSI)";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"GENESIS ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ಆದಿಕಾಂಡ ಎಂಬ ಪ್ರಥಮಭಾಗವು",
long:"GENESIS ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ಆದಿಕಾಂಡ ಎಂಬ ಪ್ರಥಮಭಾಗವು",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"EXODUS ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ವಿಮೋಚನಕಾಂಡ ಎಂಬ ದ್ವಿತೀಯ ಭಾಗವು",
long:"EXODUS ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ವಿಮೋಚನಕಾಂಡ ಎಂಬ ದ್ವಿತೀಯ ಭಾಗವು",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"LEVITICUS ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ಯಾಜಕಕಾಂಡ ಎಂಬ ತೃತೀಯ ಭಾಗವು",
long:"LEVITICUS ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ಯಾಜಕಕಾಂಡ ಎಂಬ ತೃತೀಯ ಭಾಗವು",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"NUMBERS ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ಅರಣ್ಯಕಾಂಡ ಎಂಬ ಚತುರ್ಥಭಾಗವು",
long:"NUMBERS ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ಅರಣ್ಯಕಾಂಡ ಎಂಬ ಚತುರ್ಥಭಾಗವು",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"DEUTERONOMY ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ಧರ್ಮೋಪದೇಶಕಾಂಡ ಎಂಬ ಪಂಚಮಭಾಗವು",
long:"DEUTERONOMY ಮೋಶೆಯ ಧರ್ಮಶಾಸ್ತ್ರದಲ್ಲಿ ಧರ್ಮೋಪದೇಶಕಾಂಡ ಎಂಬ ಪಂಚಮಭಾಗವು",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"THE BOOK OF JOSHUA ಯೆಹೋಶುವನು",
long:"THE BOOK OF JOSHUA ಯೆಹೋಶುವನು",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"THE BOOK OF JUDGES ನ್ಯಾಯಸ್ಥಾಪಕರು",
long:"THE BOOK OF JUDGES ನ್ಯಾಯಸ್ಥಾಪಕರು",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"THE BOOK OF RUTH ರೂತಳು",
long:"THE BOOK OF RUTH ರೂತಳು",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"THE FIRST BOOK OF SAMUEL ಸಮುವೇಲನು ಪ್ರಥಮಭಾಗ",
long:"THE FIRST BOOK OF SAMUEL ಸಮುವೇಲನು ಪ್ರಥಮಭಾಗ",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"THE SECOND BOOK OF SAMUEL ಸಮುವೇಲನು ದ್ವಿತೀಯಭಾಗ",
long:"THE SECOND BOOK OF SAMUEL ಸಮುವೇಲನು ದ್ವಿತೀಯಭಾಗ",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"THE FIRST BOOK OF KINGS ಅರಸುಗಳು ಪ್ರಥಮಭಾಗ",
long:"THE FIRST BOOK OF KINGS ಅರಸುಗಳು ಪ್ರಥಮಭಾಗ",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"THE SECOND BOOK OF KINGS ಅರಸುಗಳು ದ್ವಿತೀಯಭಾಗ",
long:"THE SECOND BOOK OF KINGS ಅರಸುಗಳು ದ್ವಿತೀಯಭಾಗ",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"THE FIRST BOOK OF CHRONICLES ಪೂರ್ವಕಾಲವೃತ್ತಾಂತ ಪ್ರಥಮಭಾಗ",
long:"THE FIRST BOOK OF CHRONICLES ಪೂರ್ವಕಾಲವೃತ್ತಾಂತ ಪ್ರಥಮಭಾಗ",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"THE SECOND BOOK OF CHRONICLES ಪೂರ್ವಕಾಲವೃತ್ತಾಂತ ದ್ವಿತೀಯಭಾಗ",
long:"THE SECOND BOOK OF CHRONICLES ಪೂರ್ವಕಾಲವೃತ್ತಾಂತ ದ್ವಿತೀಯಭಾಗ",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"THE BOOK OF EZRA ಎಜ್ರನು",
long:"THE BOOK OF EZRA ಎಜ್ರನು",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"THE BOOK OF NEHEMIAH ನೆಹೆಮೀಯ",
long:"THE BOOK OF NEHEMIAH ನೆಹೆಮೀಯ",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"THE BOOK OF ESTHER ಎಸ್ತೇರಳು",
long:"THE BOOK OF ESTHER ಎಸ್ತೇರಳು",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"THE BOOK OF JOB ಯೋಬನು",
long:"THE BOOK OF JOB ಯೋಬನು",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"THE PSALMS ಕೀರ್ತನೆಗಳು",
long:"THE PSALMS ಕೀರ್ತನೆಗಳು",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"PROVERBS ಜ್ಞಾನೋಕ್ತಿಗಳು",
long:"PROVERBS ಜ್ಞಾನೋಕ್ತಿಗಳು",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"ECCLESIASTES ಪ್ರಸಂಗಿ",
long:"ECCLESIASTES ಪ್ರಸಂಗಿ",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"THE SONG OF SONGS ಪರಮಗೀತ",
long:"THE SONG OF SONGS ಪರಮಗೀತ",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"THE BOOK OF PROPHET ISAIAH ಯೆಶಾಯನ ಪ್ರವಾದನಗ್ರಂಥ",
long:"THE BOOK OF PROPHET ISAIAH ಯೆಶಾಯನ ಪ್ರವಾದನಗ್ರಂಥ",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"THE BOOK OF PROPHET JEREMIAH ಯೆರೆಮೀಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF PROPHET JEREMIAH ಯೆರೆಮೀಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"THE LAMENTATIONS OF JEREMIAH ಯೆರೆಮೀಯನ ಪ್ರಲಾಪಗಳು",
long:"THE LAMENTATIONS OF JEREMIAH ಯೆರೆಮೀಯನ ಪ್ರಲಾಪಗಳು",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"THE BOOK OF PROPHET EZEKIEL ಯೆಹೆಜ್ಕೇಲನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF PROPHET EZEKIEL ಯೆಹೆಜ್ಕೇಲನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"THE BOOK OF PROPHET DANIEL ದಾನಿಯೇಲನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF PROPHET DANIEL ದಾನಿಯೇಲನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"THE BOOK OF PROPHET HOSEA ಹೋಶೇಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF PROPHET HOSEA ಹೋಶೇಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"THE BOOK OF PROPHET JOEL ಯೋವೇಲನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF PROPHET JOEL ಯೋವೇಲನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"THE BOOK OF PROPHET AMOS ಆಮೋಸನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF PROPHET AMOS ಆಮೋಸನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"THE BOOK OF PROPHET OBADIAH ಓಬದ್ಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF PROPHET OBADIAH ಓಬದ್ಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"THE BOOK OF JONAH ಯೋನನು",
long:"THE BOOK OF JONAH ಯೋನನು",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"THE BOOK OF MICAH ಮೀಕನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF MICAH ಮೀಕನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"THE BOOK OF NAHUM ನಹೂಮನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF NAHUM ನಹೂಮನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"THE BOOK OF HABAKKUK ಹಬಕ್ಕೂಕನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF HABAKKUK ಹಬಕ್ಕೂಕನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"THE BOOK OF ZEPHANIAH ಚೆಫನ್ಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF ZEPHANIAH ಚೆಫನ್ಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"THE BOOK OF HAGGAI ಹಗ್ಗಾಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF HAGGAI ಹಗ್ಗಾಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"THE BOOK OF ZECHARIAH ಜೆಕರ್ಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF ZECHARIAH ಜೆಕರ್ಯನ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"THE BOOK OF MALACHI ಮಲಾಕಿಯ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
long:"THE BOOK OF MALACHI ಮಲಾಕಿಯ ಪ್ರವಾದನೆಯ ಗ್ರಂಥ",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"THE GOSPEL ACCORDING TO SAINT MATTHEW ಮತ್ತಾಯನು ಬರೆದ ಸುವಾರ್ತೆ",
long:"THE GOSPEL ACCORDING TO SAINT MATTHEW ಮತ್ತಾಯನು ಬರೆದ ಸುವಾರ್ತೆ",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"THE GOSPEL ACCORDING TO SAINT LUKE ಮಾರ್ಕನು ಬರೆದ ಸುವಾರ್ತೆ",
long:"THE GOSPEL ACCORDING TO SAINT LUKE ಮಾರ್ಕನು ಬರೆದ ಸುವಾರ್ತೆ",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"THE GOSPEL ACCORDING TO SAINT LUKE ಲೂಕನು ಬರೆದ ಸುವಾರ್ತೆ",
long:"THE GOSPEL ACCORDING TO SAINT LUKE ಲೂಕನು ಬರೆದ ಸುವಾರ್ತೆ",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"THE GOSPEL ACCORDING TO SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಸುವಾರ್ತೆ",
long:"THE GOSPEL ACCORDING TO SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಸುವಾರ್ತೆ",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"THE ACTS OF THE APOSTLES ಅಪೊಸ್ತಲರ ಕೃತ್ಯಗಳು",
long:"THE ACTS OF THE APOSTLES ಅಪೊಸ್ತಲರ ಕೃತ್ಯಗಳು",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"THE EPISTLE OF SAINT PAUL TO THE ROMANS ಪೌಲನು ರೋಮಾಪುರದವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF SAINT PAUL TO THE ROMANS ಪೌಲನು ರೋಮಾಪುರದವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"THE FIRST EPISTLE OF SAINT PAUL TO THE CORINTHIANS ಪೌಲನು ಕೊರಿಂಥದವರಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
long:"THE FIRST EPISTLE OF SAINT PAUL TO THE CORINTHIANS ಪೌಲನು ಕೊರಿಂಥದವರಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"THE SECOND EPISTLE OF SAINT PAUL TO THE CORINTHIANS ಪೌಲನು ಕೊರಿಂಥದವರಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
long:"THE SECOND EPISTLE OF SAINT PAUL TO THE CORINTHIANS ಪೌಲನು ಕೊರಿಂಥದವರಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"THE EPISTLE OF SAINT PAUL TO THE GALATIANS ಪೌಲನು ಗಲಾತ್ಯದವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF SAINT PAUL TO THE GALATIANS ಪೌಲನು ಗಲಾತ್ಯದವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"THE EPISTLE OF SAINT PAUL TO THE EPHESIANS ಪೌಲನು ಎಫೆಸದವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF SAINT PAUL TO THE EPHESIANS ಪೌಲನು ಎಫೆಸದವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"THE EPISTLE OF SAINT PAUL TO THE PHILIPPIANS ಪೌಲನು ಫಿಲಿಪ್ಪಿಯವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF SAINT PAUL TO THE PHILIPPIANS ಪೌಲನು ಫಿಲಿಪ್ಪಿಯವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"THE EPISTLE OF SAINT PAUL TO THE COLOSSIANS ಪೌಲನು ಕೊಲೊಸ್ಸೆಯವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF SAINT PAUL TO THE COLOSSIANS ಪೌಲನು ಕೊಲೊಸ್ಸೆಯವರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"THE FIRST EPISTLE OF SAINT PAUL TO THE THESSALONIANS ಪೌಲನು ಥೆಸಲೋನಿಕದವರಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
long:"THE FIRST EPISTLE OF SAINT PAUL TO THE THESSALONIANS ಪೌಲನು ಥೆಸಲೋನಿಕದವರಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"THE SECOND EPISTLE OF SAINT PAUL TO THE THESSALONIANS ಪೌಲನು ಥೆಸಲೋನಿಕದವರಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
long:"THE SECOND EPISTLE OF SAINT PAUL TO THE THESSALONIANS ಪೌಲನು ಥೆಸಲೋನಿಕದವರಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"THE FIRST EPISTLE OF SAINT PAUL TO TIMOTHY ಪೌಲನು ತಿಮೊಥೆಯನಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
long:"THE FIRST EPISTLE OF SAINT PAUL TO TIMOTHY ಪೌಲನು ತಿಮೊಥೆಯನಿಗೆ ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"THE SECOND EPISTLE OF SAINT PAUL TO TIMOTHY ಪೌಲನು ತಿಮೊಥೆಯನಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
long:"THE SECOND EPISTLE OF SAINT PAUL TO TIMOTHY ಪೌಲನು ತಿಮೊಥೆಯನಿಗೆ ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"THE EPISTLE OF SAINT PAUL TO TITUS ಪೌಲನು ತೀತನಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF SAINT PAUL TO TITUS ಪೌಲನು ತೀತನಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"THE EPISTLE OF SAINT PAUL TO PHILEMON ಪೌಲನು ಫಿಲೆಮೋನನಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF SAINT PAUL TO PHILEMON ಪೌಲನು ಫಿಲೆಮೋನನಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"THE EPISTLE TO THE HEBREWS ಇಬ್ರಿಯರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE TO THE HEBREWS ಇಬ್ರಿಯರಿಗೆ ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"THE EPISTLE OF SAINT JAMES ಯಾಕೋಬನು ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF SAINT JAMES ಯಾಕೋಬನು ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"THE FIRST EPISTLE OF SAINT PETER ಪೇತ್ರನು ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
long:"THE FIRST EPISTLE OF SAINT PETER ಪೇತ್ರನು ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"THE SECOND EPISTLE OF SAINT PETER ಪೇತ್ರನು ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
long:"THE SECOND EPISTLE OF SAINT PETER ಪೇತ್ರನು ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"THE FIRST EPISTLE OF SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
long:"THE FIRST EPISTLE OF SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಮೊದಲನೆಯ ಪತ್ರಿಕೆ",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"THE SECOND EPISTLE OF SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
long:"THE SECOND EPISTLE OF SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಎರಡನೆಯ ಪತ್ರಿಕೆ",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"THE THIRD EPISTLE OF SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಮೂರನೆಯ ಪತ್ರಿಕೆ",
long:"THE THIRD EPISTLE OF SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಮೂರನೆಯ ಪತ್ರಿಕೆ",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"THE EPISTLE OF JUDE ಯೂದನು ಬರೆದ ಪತ್ರಿಕೆ",
long:"THE EPISTLE OF JUDE ಯೂದನು ಬರೆದ ಪತ್ರಿಕೆ",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"THE REVELATION TO SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಪ್ರಕಟನೆ",
long:"THE REVELATION TO SAINT JOHN ಯೋಹಾನನು ಬರೆದ ಪ್ರಕಟನೆ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
