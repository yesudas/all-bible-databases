biblename = "jivən səndesh";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"मत्तीक अनुसार शुभ समाचार",
long:"मत्तीक अनुसार शुभ समाचार",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"मरकुसक अनुसार शुभ समाचार",
long:"मरकुसक अनुसार शुभ समाचार",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"लूकाक अनुसार शुभ समाचार",
long:"लूकाक अनुसार शुभ समाचार",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"यूहन्‍नाक अनुसार शुभ समाचार",
long:"यूहन्‍नाक अनुसार शुभ समाचार",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"मसीह-दूत सभक काज",
long:"मसीह-दूत सभक काज",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"रोम नगरक मण्‍डली केँ पौलुसक पत्र",
long:"रोम नगरक मण्‍डली केँ पौलुसक पत्र",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"कोरिन्‍थ नगरक मण्‍डली केँ पौलुसक पहिल पत्र",
long:"कोरिन्‍थ नगरक मण्‍डली केँ पौलुसक पहिल पत्र",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"कोरिन्‍थ नगरक मण्‍डली केँ पौलुसक दोसर पत्र",
long:"कोरिन्‍थ नगरक मण्‍डली केँ पौलुसक दोसर पत्र",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"गलातिया प्रदेशक मण्‍डली सभ केँ पौलुसक पत्र",
long:"गलातिया प्रदेशक मण्‍डली सभ केँ पौलुसक पत्र",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"इफिसुस नगरक मण्‍डली केँ पौलुसक पत्र",
long:"इफिसुस नगरक मण्‍डली केँ पौलुसक पत्र",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"फिलिप्‍पी नगरक मण्‍डली केँ पौलुसक पत्र",
long:"फिलिप्‍पी नगरक मण्‍डली केँ पौलुसक पत्र",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"कुलुस्‍से नगरक मण्‍डली केँ पौलुसक पत्र",
long:"कुलुस्‍से नगरक मण्‍डली केँ पौलुसक पत्र",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"थिसलुनिका नगरक मण्‍डली केँ पौलुसक पहिल पत्र",
long:"थिसलुनिका नगरक मण्‍डली केँ पौलुसक पहिल पत्र",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"थिसलुनिका नगरक मण्‍डली केँ पौलुसक दोसर पत्र",
long:"थिसलुनिका नगरक मण्‍डली केँ पौलुसक दोसर पत्र",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"तिमुथियुस केँ पौलुसक पहिल पत्र",
long:"तिमुथियुस केँ पौलुसक पहिल पत्र",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"तिमुथियुस केँ पौलुसक दोसर पत्र",
long:"तिमुथियुस केँ पौलुसक दोसर पत्र",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"तीतुस केँ पौलुसक पत्र",
long:"तीतुस केँ पौलुसक पत्र",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"फिलेमोन केँ पौलुसक पत्र",
long:"फिलेमोन केँ पौलुसक पत्र",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"इब्रानी विश्‍वासी सभक लेल पत्र",
long:"इब्रानी विश्‍वासी सभक लेल पत्र",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"याकूबक पत्र",
long:"याकूबक पत्र",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"पत्रुसक पहिल पत्र",
long:"पत्रुसक पहिल पत्र",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"पत्रुसक दोसर पत्र",
long:"पत्रुसक दोसर पत्र",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"यूहन्‍नाक पहिल पत्र",
long:"यूहन्‍नाक पहिल पत्र",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"यूहन्‍नाक दोसर पत्र",
long:"यूहन्‍नाक दोसर पत्र",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"यूहन्‍नाक तेसर पत्र",
long:"यूहन्‍नाक तेसर पत्र",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"यहूदाक पत्र",
long:"यहूदाक पत्र",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"प्रकाशित-वाक्‍य",
long:"प्रकाशित-वाक्‍य",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
