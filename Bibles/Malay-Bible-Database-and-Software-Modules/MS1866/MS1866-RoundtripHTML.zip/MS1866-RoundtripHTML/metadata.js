biblename = "Kitab Alkudus: Injil Isa Almasih 1866 (Keasberry)";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Intro",
short:"_Introduction_",
long:"_Introduction_",
osis:"x-Intr",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Mat",
short:"Injil Mathius",
long:"Injil Mathius",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mrk",
short:"Injil Markus",
long:"Injil Markus",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luk",
short:"Injil Lukas",
long:"Injil Lukas",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"Yoh",
short:"Injil Yahya",
long:"Injil Yahya",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Kis",
short:"Kesah",
long:"Kesah",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rm",
short:"Rom",
long:"Rom",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Kor",
short:"1 Korinthus",
long:"1 Korinthus",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Kor",
short:"2 Korinthus",
long:"2 Korinthus",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"Galatia",
long:"Galatia",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Ef",
short:"Efesus",
long:"Efesus",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Flp",
short:"Filippi",
long:"Filippi",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Kol",
short:"Kolossi",
long:"Kolossi",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Tes",
short:"1 Thessalonika",
long:"1 Thessalonika",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Tes",
short:"2 Thessalonika",
long:"2 Thessalonika",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"1 Timothius",
long:"1 Timothius",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"2 Timothius",
long:"2 Timothius",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Tit",
short:"Titus",
long:"Titus",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Flm",
short:"Philemon",
long:"Philemon",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Ibr",
short:"Ibrani",
long:"Ibrani",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Yak",
short:"Yakob",
long:"Yakob",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Ptr",
short:"1 Petrus",
long:"1 Petrus",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Ptr",
short:"2 Petrus",
long:"2 Petrus",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Yoh",
short:"1 Yahya",
long:"1 Yahya",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Yoh",
short:"2 Yahya",
long:"2 Yahya",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3Yoh",
short:"3 Yahya",
long:"3 Yahya",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Yud",
short:"Yahuda",
long:"Yahuda",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Why",
short:"Wahi",
long:"Wahi",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
