biblename = "Malayalam Bible: Easy to Read, 2007";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"മത്തായി എഴുതിയ സുവിശേഷം",
long:"മത്തായി എഴുതിയ സുവിശേഷം",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"മര്ക്കോസ് എഴുതിയ സുവിശേഷം",
long:"മര്ക്കോസ് എഴുതിയ സുവിശേഷം",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ലൂക്കാ എഴുതിയ സുവിശേഷം",
long:"ലൂക്കാ എഴുതിയ സുവിശേഷം",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"യോഹന്നാൻ എഴുതിയ സുവിശേഷം",
long:"യോഹന്നാൻ എഴുതിയ സുവിശേഷം",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"അപ്പസ്തോലന്മാരുടെ പ്രവര്ത്തനങ്ങൾ",
long:"അപ്പസ്തോലന്മാരുടെ പ്രവര്ത്തനങ്ങൾ",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"റോമാക്കാര്ക്കെഴുതിയ ലേഖനം",
long:"റോമാക്കാര്ക്കെഴുതിയ ലേഖനം",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"കോറിന്തോസുകാര്ക്ൿ എഴുതിയ ഒന്നാം ലേഖനം",
long:"കോറിന്തോസുകാര്ക്ൿ എഴുതിയ ഒന്നാം ലേഖനം",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"കോറിന്തോസുകാര്ക്ൿ എഴുതിയ രണ്ടാം ലേഖനം",
long:"കോറിന്തോസുകാര്ക്ൿ എഴുതിയ രണ്ടാം ലേഖനം",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ഗലാത്തിയാക്കാര്ക്ൿ എഴുതിയ ലേഖനം",
long:"ഗലാത്തിയാക്കാര്ക്ൿ എഴുതിയ ലേഖനം",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"എഫേസോസുകാര്ക്ൿ എഴുതിയ ലേഖനം",
long:"എഫേസോസുകാര്ക്ൿ എഴുതിയ ലേഖനം",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ഫിലിപ്പിയര്ക്ൿ എഴുതിയ ലേഖനം",
long:"ഫിലിപ്പിയര്ക്ൿ എഴുതിയ ലേഖനം",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"കൊളോസോസുകാര്ക്ൿ എഴുതിയ ലേഖനം",
long:"കൊളോസോസുകാര്ക്ൿ എഴുതിയ ലേഖനം",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"തെസലോനിക്കാക്കാര്ക്ൿ എഴുതിയ ഒന്നാം ലേഖനം",
long:"തെസലോനിക്കാക്കാര്ക്ൿ എഴുതിയ ഒന്നാം ലേഖനം",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"തെസലോനിക്കാക്കാര്ക്ൿ എഴുതിയ രണ്ടാം ലേഖനം",
long:"തെസലോനിക്കാക്കാര്ക്ൿ എഴുതിയ രണ്ടാം ലേഖനം",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"തിമോത്തിയോസിനെഴുതിയ ഒന്നാം ലേഖനം",
long:"തിമോത്തിയോസിനെഴുതിയ ഒന്നാം ലേഖനം",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"തിമോത്തിയോസിനെഴുതിയ രണ്ടാം ലേഖനം",
long:"തിമോത്തിയോസിനെഴുതിയ രണ്ടാം ലേഖനം",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"തീത്തോസിനെഴുതിയ ലേഖനം",
long:"തീത്തോസിനെഴുതിയ ലേഖനം",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ഫിലമോനെഴുതിയ ലേഖനം",
long:"ഫിലമോനെഴുതിയ ലേഖനം",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"ഹെബ്രായര്ക്കെഴുതിയ ലേഖനം",
long:"ഹെബ്രായര്ക്കെഴുതിയ ലേഖനം",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"യാക്കോബ് എഴുതിയ ലേഖനം",
long:"യാക്കോബ് എഴുതിയ ലേഖനം",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"പത്രോസ് എഴുതിയ ഒന്നാം ലേഖനം",
long:"പത്രോസ് എഴുതിയ ഒന്നാം ലേഖനം",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"പത്രോസ് എഴുതിയ രണ്ടാം ലേഖനം",
long:"പത്രോസ് എഴുതിയ രണ്ടാം ലേഖനം",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"യോഹന്നാൻ എഴുതിയ ഒന്നാം ലേഖനം",
long:"യോഹന്നാൻ എഴുതിയ ഒന്നാം ലേഖനം",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"യോഹന്നാൻ എഴുതിയ രണ്ടാം ലേഖനം",
long:"യോഹന്നാൻ എഴുതിയ രണ്ടാം ലേഖനം",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"യോഹന്നാൻ എഴുതിയ മൂന്നാം ലേഖനം",
long:"യോഹന്നാൻ എഴുതിയ മൂന്നാം ലേഖനം",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"യൂദാ ശ്ലീഹാ എഴുതിയ ലേഖനം",
long:"യൂദാ ശ്ലീഹാ എഴുതിയ ലേഖനം",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"യോഹന്നാനു ലഭിച്ച വെളിപാട്",
long:"യോഹന്നാനു ലഭിച്ച വെളിപാട്",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
