biblename = "Malayalam Bible, 1956";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"ഉല്പത്തി",
long:"ഉല്പത്തി",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"പുറപ്പാട്",
long:"പുറപ്പാട്",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"ലേവ്യർ",
long:"ലേവ്യർ",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"സംഖ്യകശ്",
long:"സംഖ്യകശ്",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"ആവര്ത്തനം",
long:"ആവര്ത്തനം",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"യോശുവ",
long:"യോശുവ",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"ന്യായാധിപന്മാർ",
long:"ന്യായാധിപന്മാർ",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"രൂത്ത്",
long:"രൂത്ത്",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"1 ശമൂവേൽ",
long:"1 ശമൂവേൽ",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"2 ശമൂവേൽ",
long:"2 ശമൂവേൽ",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"1 രാജാക്കന്മാർ",
long:"1 രാജാക്കന്മാർ",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"2 രാജാക്കന്മാർ",
long:"2 രാജാക്കന്മാർ",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"1 ദിനവൃത്താന്തം",
long:"1 ദിനവൃത്താന്തം",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"2 ദിനവൃത്താന്തം",
long:"2 ദിനവൃത്താന്തം",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"എസ്രാ",
long:"എസ്രാ",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"നെഹെമ്യാവ്",
long:"നെഹെമ്യാവ്",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"എസ്ഥേർ",
long:"എസ്ഥേർ",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"ഇയ്യോബ്",
long:"ഇയ്യോബ്",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"സങ്കീര്‍ത്തനങ്ങൾ",
long:"സങ്കീര്‍ത്തനങ്ങൾ",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"സദൃശ്യവാക്ക്യങ്ങൾ",
long:"സദൃശ്യവാക്ക്യങ്ങൾ",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"സഭാപ്രസംഗി",
long:"സഭാപ്രസംഗി",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"ഉത്തമഗീതം",
long:"ഉത്തമഗീതം",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"യെശയ്യാവ്",
long:"യെശയ്യാവ്",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"യിരെമ്യാവ്",
long:"യിരെമ്യാവ്",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"വിലാപങ്ങൾ",
long:"വിലാപങ്ങൾ",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"യെഹെസ്കേൽ",
long:"യെഹെസ്കേൽ",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"ദാനീയേൽ",
long:"ദാനീയേൽ",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"ഹോശേയ",
long:"ഹോശേയ",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"യോവേൽ",
long:"യോവേൽ",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"ആമോസ്",
long:"ആമോസ്",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"ഒബദ്യാവ്",
long:"ഒബദ്യാവ്",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"യോനാ",
long:"യോനാ",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"മീഖാ",
long:"മീഖാ",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"നഹൂം",
long:"നഹൂം",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"ഹബക്കൂക്ൿ",
long:"ഹബക്കൂക്ൿ",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"സെഫന്യാവ്",
long:"സെഫന്യാവ്",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"ഹഗ്ഗായി",
long:"ഹഗ്ഗായി",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"സെഖര്യാവ്",
long:"സെഖര്യാവ്",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"മലാഖി",
long:"മലാഖി",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"മത്തായി എഴുതിയ സുവിശേഷം",
long:"മത്തായി എഴുതിയ സുവിശേഷം",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"മര്ക്കോസ് എഴുതിയ സുവിശേഷം",
long:"മര്ക്കോസ് എഴുതിയ സുവിശേഷം",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ലൂക്കാ എഴുതിയ സുവിശേഷം",
long:"ലൂക്കാ എഴുതിയ സുവിശേഷം",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"യോഹന്നാൻ എഴുതിയ സുവിശേഷം",
long:"യോഹന്നാൻ എഴുതിയ സുവിശേഷം",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"അപ്പസ്തോലന്മാരുടെ പ്രവര്ത്തനങ്ങൾ",
long:"അപ്പസ്തോലന്മാരുടെ പ്രവര്ത്തനങ്ങൾ",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"റോമാക്കാര്ക്കെഴുതിയ ലേഖനം",
long:"റോമാക്കാര്ക്കെഴുതിയ ലേഖനം",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"കോറിന്തോസുകാര്ക്ൿ എഴുതിയ ഒന്നാം ലേഖനം",
long:"കോറിന്തോസുകാര്ക്ൿ എഴുതിയ ഒന്നാം ലേഖനം",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"കോറിന്തോസുകാര്ക്ൿ എഴുതിയ രണ്ടാം ലേഖനം",
long:"കോറിന്തോസുകാര്ക്ൿ എഴുതിയ രണ്ടാം ലേഖനം",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ഗലാത്തിയാക്കാര്ക്ൿ എഴുതിയ ലേഖനം",
long:"ഗലാത്തിയാക്കാര്ക്ൿ എഴുതിയ ലേഖനം",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"എഫേസോസുകാര്ക്ൿ എഴുതിയ ലേഖനം",
long:"എഫേസോസുകാര്ക്ൿ എഴുതിയ ലേഖനം",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ഫിലിപ്പിയര്ക്ൿ എഴുതിയ ലേഖനം",
long:"ഫിലിപ്പിയര്ക്ൿ എഴുതിയ ലേഖനം",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"കൊളോസോസുകാര്ക്ൿ എഴുതിയ ലേഖനം",
long:"കൊളോസോസുകാര്ക്ൿ എഴുതിയ ലേഖനം",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"തെസലോനിക്കാക്കാര്ക്ൿ എഴുതിയ ഒന്നാം ലേഖനം",
long:"തെസലോനിക്കാക്കാര്ക്ൿ എഴുതിയ ഒന്നാം ലേഖനം",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"തെസലോനിക്കാക്കാര്ക്ൿ എഴുതിയ രണ്ടാം ലേഖനം",
long:"തെസലോനിക്കാക്കാര്ക്ൿ എഴുതിയ രണ്ടാം ലേഖനം",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"തിമോത്തിയോസിനെഴുതിയ ഒന്നാം ലേഖനം",
long:"തിമോത്തിയോസിനെഴുതിയ ഒന്നാം ലേഖനം",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"തിമോത്തിയോസിനെഴുതിയ രണ്ടാം ലേഖനം",
long:"തിമോത്തിയോസിനെഴുതിയ രണ്ടാം ലേഖനം",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"തീത്തോസിനെഴുതിയ ലേഖനം",
long:"തീത്തോസിനെഴുതിയ ലേഖനം",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ഫിലമോനെഴുതിയ ലേഖനം",
long:"ഫിലമോനെഴുതിയ ലേഖനം",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"ഹെബ്രായര്ക്കെഴുതിയ ലേഖനം",
long:"ഹെബ്രായര്ക്കെഴുതിയ ലേഖനം",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"യാക്കോബ് എഴുതിയ ലേഖനം",
long:"യാക്കോബ് എഴുതിയ ലേഖനം",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"പത്രോസ് എഴുതിയ ഒന്നാം ലേഖനം",
long:"പത്രോസ് എഴുതിയ ഒന്നാം ലേഖനം",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"പത്രോസ് എഴുതിയ രണ്ടാം ലേഖനം",
long:"പത്രോസ് എഴുതിയ രണ്ടാം ലേഖനം",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"യോഹന്നാൻ എഴുതിയ ഒന്നാം ലേഖനം",
long:"യോഹന്നാൻ എഴുതിയ ഒന്നാം ലേഖനം",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"യോഹന്നാൻ എഴുതിയ രണ്ടാം ലേഖനം",
long:"യോഹന്നാൻ എഴുതിയ രണ്ടാം ലേഖനം",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"യോഹന്നാൻ എഴുതിയ മൂന്നാം ലേഖനം",
long:"യോഹന്നാൻ എഴുതിയ മൂന്നാം ലേഖനം",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"യൂദാ ശ്ലീഹാ എഴുതിയ ലേഖനം",
long:"യൂദാ ശ്ലീഹാ എഴുതിയ ലേഖനം",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"യോഹന്നാനു ലഭിച്ച വെളിപാട്",
long:"യോഹന്നാനു ലഭിച്ച വെളിപാട്",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
