biblename = "മലയാളബൈബിള്‍-നൂതനപരിഭാഷ";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Intro",
short:"_Introduction_",
long:"_Introduction_",
osis:"x-Intr",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"മത്തായി",
long:"മത്തായി",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"മർക്കോസ്",
long:"മർക്കോസ്",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ലൂക്കോസ്",
long:"ലൂക്കോസ്",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"യോഹന്നാൻ",
long:"യോഹന്നാൻ",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"അപ്പോ.പ്രവൃത്തികൾ",
long:"അപ്പോ.പ്രവൃത്തികൾ",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"റോമർ",
long:"റോമർ",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"1 കൊരിന്ത്യർ",
long:"1 കൊരിന്ത്യർ",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"2 കൊരിന്ത്യർ",
long:"2 കൊരിന്ത്യർ",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ഗലാത്യർ",
long:"ഗലാത്യർ",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"എഫേസ്യർ",
long:"എഫേസ്യർ",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ഫിലിപ്പിയർ",
long:"ഫിലിപ്പിയർ",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"കൊലോസ്യർ",
long:"കൊലോസ്യർ",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"1 തെസ്സലോനിക്യർ",
long:"1 തെസ്സലോനിക്യർ",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"2 തെസ്സലോനിക്യർ",
long:"2 തെസ്സലോനിക്യർ",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"1 തിമോത്തിയോസ്",
long:"1 തിമോത്തിയോസ്",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"2 തിമോത്തിയോസ്",
long:"2 തിമോത്തിയോസ്",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"തീത്തോസ്",
long:"തീത്തോസ്",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ഫിലേമോൻ",
long:"ഫിലേമോൻ",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"എബ്രായർ",
long:"എബ്രായർ",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"യാക്കോബ്",
long:"യാക്കോബ്",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"1 പത്രോസ്",
long:"1 പത്രോസ്",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"2 പത്രോസ്",
long:"2 പത്രോസ്",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"1 യോഹന്നാൻ",
long:"1 യോഹന്നാൻ",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"2 യോഹന്നാൻ",
long:"2 യോഹന്നാൻ",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"3 യോഹന്നാൻ",
long:"3 യോഹന്നാൻ",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"യൂദാ",
long:"യൂദാ",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"വെളിപ്പാട്",
long:"വെളിപ്പാട്",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
