biblename = "पवित्र शास्त्र - R.V. (BSI)";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"उत्पत्ती",
long:"उत्पत्ती",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"निर्गम",
long:"निर्गम",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"लेवीय",
long:"लेवीय",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"गणना",
long:"गणना",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"अनुवाद",
long:"अनुवाद",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"यहोशवा",
long:"यहोशवा",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"शास्ते",
long:"शास्ते",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"रूथ",
long:"रूथ",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"१ शमुवेल",
long:"१ शमुवेल",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"२ शमुवेल",
long:"२ शमुवेल",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"१ राजे",
long:"१ राजे",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"२ राजे",
long:"२ राजे",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"१ इतिहास",
long:"१ इतिहास",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"२ इतिहास",
long:"२ इतिहास",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"एज्रा",
long:"एज्रा",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"नहेम्या",
long:"नहेम्या",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"एस्तेर",
long:"एस्तेर",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"ईयोब",
long:"ईयोब",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"स्तोत्रसंहिता",
long:"स्तोत्रसंहिता",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"नीतिसूत्रे",
long:"नीतिसूत्रे",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"उपदेशक",
long:"उपदेशक",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"गीतरत्न",
long:"गीतरत्न",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"यशया",
long:"यशया",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"यिर्मया",
long:"यिर्मया",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"यिर्मयाचे विलापगीत",
long:"यिर्मयाचे विलापगीत",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"यहेज्केल",
long:"यहेज्केल",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"दानीएल",
long:"दानीएल",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"होशेय",
long:"होशेय",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"योएल",
long:"योएल",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"आमोस",
long:"आमोस",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"ओबद्या",
long:"ओबद्या",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"योना",
long:"योना",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"मीखा",
long:"मीखा",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"नहूम",
long:"नहूम",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"हबक्कूक",
long:"हबक्कूक",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"सफन्या",
long:"सफन्या",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"हाग्गय",
long:"हाग्गय",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"जखर्‍या",
long:"जखर्‍या",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"मलाखी",
long:"मलाखी",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"मत्तयकृत शुभवर्तमान",
long:"मत्तयकृत शुभवर्तमान",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"मार्ककृत शुभवर्तमान",
long:"मार्ककृत शुभवर्तमान",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"लूककृत शुभवर्तमान",
long:"लूककृत शुभवर्तमान",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"योहानकृत शुभवर्तमान",
long:"योहानकृत शुभवर्तमान",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"प्रेषितांची कृत्ये",
long:"प्रेषितांची कृत्ये",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"पौलाचे रोमकरांस पत्र",
long:"पौलाचे रोमकरांस पत्र",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"पौलाचे करिंथकरांस पहिले पत्र",
long:"पौलाचे करिंथकरांस पहिले पत्र",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"पौलाचे करिंथकरांस दुसरे पत्र",
long:"पौलाचे करिंथकरांस दुसरे पत्र",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"पौलाचे गलतीकरांस पत्र",
long:"पौलाचे गलतीकरांस पत्र",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"पौलाचे इफिसकरांस पत्र",
long:"पौलाचे इफिसकरांस पत्र",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"पौलाचे फिलिप्पैकरांस पत्र",
long:"पौलाचे फिलिप्पैकरांस पत्र",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"पौलाचे कलस्सैकरांस पत्र",
long:"पौलाचे कलस्सैकरांस पत्र",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"पौलाचे थेस्सलनीकाकरांस पहिले पत्र",
long:"पौलाचे थेस्सलनीकाकरांस पहिले पत्र",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"पौलाचे थेस्सलनीकाकरांस दुसरे पत्र",
long:"पौलाचे थेस्सलनीकाकरांस दुसरे पत्र",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"पौलाचे तीमथ्याला पहिले पत्र",
long:"पौलाचे तीमथ्याला पहिले पत्र",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"पौलाचे तीमथ्याला दुसरे पत्र",
long:"पौलाचे तीमथ्याला दुसरे पत्र",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"पौलाचे तीताला पत्र",
long:"पौलाचे तीताला पत्र",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"पौलाचे फिलेमोनाला पत्र",
long:"पौलाचे फिलेमोनाला पत्र",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"इब्री लोकांस पत्र",
long:"इब्री लोकांस पत्र",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"याकोबाचे पत्र",
long:"याकोबाचे पत्र",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"पेत्राचे पहिले पत्र",
long:"पेत्राचे पहिले पत्र",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"पेत्राचे दुसरे पत्र",
long:"पेत्राचे दुसरे पत्र",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"योहानाचे पहिले पत्र",
long:"योहानाचे पहिले पत्र",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"योहानाचे दुसरे पत्र",
long:"योहानाचे दुसरे पत्र",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"योहानाचे तिसरे पत्र",
long:"योहानाचे तिसरे पत्र",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"यहूदाचे पत्र",
long:"यहूदाचे पत्र",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"योहानाला झालेले प्रकटीकरण",
long:"योहानाला झालेले प्रकटीकरण",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
