biblename = "ପବିତ୍ର ବାଇବଲ (Re-edited) - (BSI)";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"ଆଦି ପୁସ୍ତକ ଅର୍ଥାତ୍ ମୋଶା ଲିଖିତ ପ୍ରଥମ ପୁସ୍ତକ",
long:"ଆଦି ପୁସ୍ତକ ଅର୍ଥାତ୍ ମୋଶା ଲିଖିତ ପ୍ରଥମ ପୁସ୍ତକ",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"ଯାତ୍ରା ପୁସ୍ତକ ଅର୍ଥାତ୍ ମୋଶା ଲିଖିତ ଦ୍ଵିତୀୟ ପୁସ୍ତକ",
long:"ଯାତ୍ରା ପୁସ୍ତକ ଅର୍ଥାତ୍ ମୋଶା ଲିଖିତ ଦ୍ଵିତୀୟ ପୁସ୍ତକ",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"ଲେବୀୟ ପୁସ୍ତକ ଅର୍ଥାତ୍ ମୋଶା ଲିଖିତ ତୃତୀୟ ପୁସ୍ତକ",
long:"ଲେବୀୟ ପୁସ୍ତକ ଅର୍ଥାତ୍ ମୋଶା ଲିଖିତ ତୃତୀୟ ପୁସ୍ତକ",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"ଗଣନା ପୁସ୍ତକ ଅର୍ଥାତ୍ ଇସ୍ରାଏଲ ଯୋଦ୍ଧାଙ୍କର ଗଣନା",
long:"ଗଣନା ପୁସ୍ତକ ଅର୍ଥାତ୍ ଇସ୍ରାଏଲ ଯୋଦ୍ଧାଙ୍କର ଗଣନା",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"ଦ୍ଵିତୀୟ ବିବରଣ ଅର୍ଥାତ୍ ମୋଶା ଲିଖିତ ପଞ୍ଚମ ପୁସ୍ତକ ହୋରେବ ତ୍ୟାଗ କରିବାକୁ ଆଦେଶ",
long:"ଦ୍ଵିତୀୟ ବିବରଣ ଅର୍ଥାତ୍ ମୋଶା ଲିଖିତ ପଞ୍ଚମ ପୁସ୍ତକ ହୋରେବ ତ୍ୟାଗ କରିବାକୁ ଆଦେଶ",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"ଯିହୋଶୂୟଙ୍କର ପୁସ୍ତକ",
long:"ଯିହୋଶୂୟଙ୍କର ପୁସ୍ତକ",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"ବିଚାରକର୍ତ୍ତାମାନଙ୍କ ବିବରଣ",
long:"ବିଚାରକର୍ତ୍ତାମାନଙ୍କ ବିବରଣ",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"ରୂତର ବିବରଣ ପୁସ୍ତକ",
long:"ରୂତର ବିବରଣ ପୁସ୍ତକ",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"ଶାମୁୟେଲଙ୍କ ପ୍ରଥମ ପୁସ୍ତକ",
long:"ଶାମୁୟେଲଙ୍କ ପ୍ରଥମ ପୁସ୍ତକ",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"ଶାମୁୟେଲଙ୍କ ଦ୍ଵିତୀୟ ପୁସ୍ତକ",
long:"ଶାମୁୟେଲଙ୍କ ଦ୍ଵିତୀୟ ପୁସ୍ତକ",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"ରାଜାବଳୀର ପ୍ରଥମ ପୁସ୍ତକ",
long:"ରାଜାବଳୀର ପ୍ରଥମ ପୁସ୍ତକ",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"ରାଜାବଳୀର ଦ୍ଵିତୀୟ ପୁସ୍ତକ",
long:"ରାଜାବଳୀର ଦ୍ଵିତୀୟ ପୁସ୍ତକ",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"ବଂଶାବଳୀର ପ୍ରଥମ ପୁସ୍ତକ",
long:"ବଂଶାବଳୀର ପ୍ରଥମ ପୁସ୍ତକ",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"ବଂଶାବଳୀର ଦ୍ଵିତୀୟ ପୁସ୍ତକ",
long:"ବଂଶାବଳୀର ଦ୍ଵିତୀୟ ପୁସ୍ତକ",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"ଏଜ୍ରା",
long:"ଏଜ୍ରା",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"ନିହିମୀୟାଙ୍କର ପୁସ୍ତକ",
long:"ନିହିମୀୟାଙ୍କର ପୁସ୍ତକ",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"ଏଷ୍ଟର ବିବରଣ",
long:"ଏଷ୍ଟର ବିବରଣ",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"ଆୟୁବ ପୁସ୍ତକ",
long:"ଆୟୁବ ପୁସ୍ତକ",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"ଗୀତସଂହିତା",
long:"ଗୀତସଂହିତା",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"ହିତୋପଦେଶ",
long:"ହିତୋପଦେଶ",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"ଉପଦେଶକ",
long:"ଉପଦେଶକ",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"ପରମ ଗୀତ",
long:"ପରମ ଗୀତ",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"ଯିଶାଇୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କର ପୁସ୍ତକ",
long:"ଯିଶାଇୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କର ପୁସ୍ତକ",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"ଯିରିମୀୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ଯିରିମୀୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"ଯିରିମୀୟଙ୍କ ବିଳାପ",
long:"ଯିରିମୀୟଙ୍କ ବିଳାପ",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"ଯିହିଜିକଲ୍ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ଯିହିଜିକଲ୍ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"ଦାନିୟେଲଙ୍କ ପୁସ୍ତକ",
long:"ଦାନିୟେଲଙ୍କ ପୁସ୍ତକ",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"ହୋଶେୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ହୋଶେୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"ଯୋୟେଲ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ଯୋୟେଲ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"ଆମୋଷ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ଆମୋଷ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"ଓବଦୀୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ଓବଦୀୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"ଯୂନସ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ଯୂନସ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"ମୀଖା ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ମୀଖା ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"ନାହୂମ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ନାହୂମ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"ହବକ୍କୂକ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ହବକ୍କୂକ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"ସିଫନୀୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ସିଫନୀୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"ହାଗୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ହାଗୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"ଯିଖରୀୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ଯିଖରୀୟ ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"ମଲାଖି ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
long:"ମଲାଖି ଭବିଷ୍ୟଦ୍ବକ୍ତାଙ୍କ ପୁସ୍ତକ",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"ମାଥିଉ ଲିଖିତ ସୁସମାଚାର",
long:"ମାଥିଉ ଲିଖିତ ସୁସମାଚାର",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"ମାର୍କ ଲିଖିତ ସୁସମାଚାର",
long:"ମାର୍କ ଲିଖିତ ସୁସମାଚାର",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ଲୂକ ଲିଖିତ ସୁସମାଚାର",
long:"ଲୂକ ଲିଖିତ ସୁସମାଚାର",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"ଯୋହନ ଲିଖିତ ସୁସମାଚାର",
long:"ଯୋହନ ଲିଖିତ ସୁସମାଚାର",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"ପ୍ରେରିତମାନଙ୍କର କାର୍ଯ୍ୟର ବିବରଣ",
long:"ପ୍ରେରିତମାନଙ୍କର କାର୍ଯ୍ୟର ବିବରଣ",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"ରୋମୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
long:"ରୋମୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"କରିନ୍ଥୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପାଉଲଙ୍କ ପ୍ରଥମ ପତ୍ର",
long:"କରିନ୍ଥୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପାଉଲଙ୍କ ପ୍ରଥମ ପତ୍ର",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"କରିନ୍ଥୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପାଉଲଙ୍କ ଦ୍ଵିତୀୟ ପତ୍ର",
long:"କରିନ୍ଥୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପାଉଲଙ୍କ ଦ୍ଵିତୀୟ ପତ୍ର",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ଗାଲାତୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
long:"ଗାଲାତୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"ଏଫିସୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
long:"ଏଫିସୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ଫିଲିପ୍‍ପୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
long:"ଫିଲିପ୍‍ପୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"କଲସୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
long:"କଲସୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପତ୍ର",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"ଥେସଲନୀକୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପ୍ରଥମ ପତ୍ର",
long:"ଥେସଲନୀକୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ପ୍ରଥମ ପତ୍ର",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"ଥେସଲନୀକୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ଦ୍ଵିତୀୟ ପତ୍ର",
long:"ଥେସଲନୀକୀୟ ମଣ୍ତଳୀ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କ ଦ୍ଵିତୀୟ ପତ୍ର",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"ତୀମଥିଙ୍କ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କର ପ୍ରଥମ ପତ୍ର",
long:"ତୀମଥିଙ୍କ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କର ପ୍ରଥମ ପତ୍ର",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"ତୀମଥିଙ୍କ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କର ଦ୍ଵିତୀୟ ପତ୍ର",
long:"ତୀମଥିଙ୍କ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କର ଦ୍ଵିତୀୟ ପତ୍ର",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"ତୀତସଙ୍କ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କର ପତ୍ର",
long:"ତୀତସଙ୍କ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କର ପତ୍ର",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ଫିଲୀମୋନଙ୍କ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କର ପତ୍ର",
long:"ଫିଲୀମୋନଙ୍କ ନିକଟକୁ ପ୍ରେରିତ ପାଉଲଙ୍କର ପତ୍ର",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"ଏବ୍ରୀମାନଙ୍କ ନିକଟକୁ ପତ୍ର",
long:"ଏବ୍ରୀମାନଙ୍କ ନିକଟକୁ ପତ୍ର",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"ଯାକୁବଙ୍କ ପତ୍ର",
long:"ଯାକୁବଙ୍କ ପତ୍ର",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"ପିତରଙ୍କ ପ୍ରଥମ ପତ୍ର",
long:"ପିତରଙ୍କ ପ୍ରଥମ ପତ୍ର",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"ପିତରଙ୍କ ଦ୍ଵିତୀୟ ପତ୍ର",
long:"ପିତରଙ୍କ ଦ୍ଵିତୀୟ ପତ୍ର",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"ଯୋହନଙ୍କ ପ୍ରଥମ ପତ୍ର",
long:"ଯୋହନଙ୍କ ପ୍ରଥମ ପତ୍ର",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"ଯୋହନଙ୍କ ଦ୍ଵିତୀୟ ପତ୍ର",
long:"ଯୋହନଙ୍କ ଦ୍ଵିତୀୟ ପତ୍ର",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"ଯୋହନଙ୍କ ତୃତୀୟ ପତ୍ର",
long:"ଯୋହନଙ୍କ ତୃତୀୟ ପତ୍ର",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"ଯିହୂଦାଙ୍କ ପତ୍ର",
long:"ଯିହୂଦାଙ୍କ ପତ୍ର",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"ଯୋହନଙ୍କ ପ୍ରତି ପ୍ରକାଶିତ ବାକ୍ୟ",
long:"ଯୋହନଙ୍କ ପ୍ରତି ପ୍ରକାଶିତ ବାକ୍ୟ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
