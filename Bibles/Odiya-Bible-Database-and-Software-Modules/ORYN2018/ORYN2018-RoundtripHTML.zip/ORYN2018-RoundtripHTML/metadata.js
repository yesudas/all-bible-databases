biblename = "ପବିତ୍ର ବାଇବଲ (CL) NT (BSI)";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Intro",
short:"_Introduction_",
long:"_Introduction_",
osis:"x-Intr",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"ମାଥିଉଲିଖିତ ସୁସମାଚାର",
long:"ମାଥିଉଲିଖିତ ସୁସମାଚାର",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"ମାର୍କଲିଖିତ ସୁସମାଚାର",
long:"ମାର୍କଲିଖିତ ସୁସମାଚାର",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ଲୂକ",
long:"ଲୂକ",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"ଯୋହନ",
long:"ଯୋହନ",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"ପ୍ରେରିତ",
long:"ପ୍ରେରିତ",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"ରୋମୀୟ",
long:"ରୋମୀୟ",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"କରିନ୍ଥୀୟମାନଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ",
long:"କରିନ୍ଥୀୟମାନଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"କରିନ୍ଥୀୟମାନଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
long:"କରିନ୍ଥୀୟମାନଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ଗାଲାତୀୟ",
long:"ଗାଲାତୀୟ",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"ଏଫିସୀୟ",
long:"ଏଫିସୀୟ",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ଫିଲିପୀୟ",
long:"ଫିଲିପୀୟ",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"କଲସୀୟ",
long:"କଲସୀୟ",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"ଥେସଲନିକୀୟମାନଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ପ୍ରଥମ ପତ୍ର",
long:"ଥେସଲନିକୀୟମାନଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ପ୍ରଥମ ପତ୍ର",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"ଥେସଲନିକୀୟମାନଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
long:"ଥେସଲନିକୀୟମାନଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"ତୀମଥିଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ପ୍ରଥମ ପତ୍ର",
long:"ତୀମଥିଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ପ୍ରଥମ ପତ୍ର",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"ତୀମଥିଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
long:"ତୀମଥିଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"ତୀତସଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ପତ୍ର",
long:"ତୀତସଙ୍କ ନିକଟକୁ ପାଉଲଙ୍କ ପତ୍ର",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ଫିଲୀମନ",
long:"ଫିଲୀମନ",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"ହିବ୍ରୁମାନଙ୍କୁ ଲିଖିତ ପତ୍ର",
long:"ହିବ୍ରୁମାନଙ୍କୁ ଲିଖିତ ପତ୍ର",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"ଯାକୁବଙ୍କ ପତ୍ର",
long:"ଯାକୁବଙ୍କ ପତ୍ର",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"ପିତରଙ୍କ ପ୍ରଥମ ପତ୍ର",
long:"ପିତରଙ୍କ ପ୍ରଥମ ପତ୍ର",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"ପିତରଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
long:"ପିତରଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"ଯୋହନଙ୍କ ପ୍ରଥମ ପତ୍ର",
long:"ଯୋହନଙ୍କ ପ୍ରଥମ ପତ୍ର",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"ଯୋହନଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
long:"ଯୋହନଙ୍କ ଦ୍ୱିତୀୟ ପତ୍ର",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"ଯୋହନଙ୍କ ତୃତୀୟ ପତ୍ର",
long:"ଯୋହନଙ୍କ ତୃତୀୟ ପତ୍ର",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"ଯିହୁଦାଙ୍କ ପତ୍ର",
long:"ଯିହୁଦାଙ୍କ ପତ୍ର",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"ପ୍ରକାଶିତ ବାକ୍ୟ",
long:"ପ୍ରକାଶିତ ବାକ୍ୟ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
