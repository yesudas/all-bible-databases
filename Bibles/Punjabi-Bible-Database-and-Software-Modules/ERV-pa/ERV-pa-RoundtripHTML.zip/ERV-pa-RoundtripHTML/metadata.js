biblename = "Punjabi New Testament: Easy to Read, 2002";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"ਮੱਤੀ ਦੀ ਇੰਜੀਲ",
long:"ਮੱਤੀ ਦੀ ਇੰਜੀਲ",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"ਮਰਕੁਸ ਦੀ ਇੰਜੀਲ",
long:"ਮਰਕੁਸ ਦੀ ਇੰਜੀਲ",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ਲੂਕਾ ਦੀ ਇੰਜੀਲ",
long:"ਲੂਕਾ ਦੀ ਇੰਜੀਲ",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"ਯੂਹੰਨਾ ਦੀ ਇੰਜੀਲ",
long:"ਯੂਹੰਨਾ ਦੀ ਇੰਜੀਲ",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"ਰਸੂਲਾਂ ਦੇ ਕਰਤੱਬ",
long:"ਰਸੂਲਾਂ ਦੇ ਕਰਤੱਬ",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"ਰੋਮੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
long:"ਰੋਮੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"ਕੁਰਿੰਥੀਆਂ ਨੂੰ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
long:"ਕੁਰਿੰਥੀਆਂ ਨੂੰ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"ਕੁਰਿੰਥੀਆਂ ਨੂੰ ਦੂਜੀ ਪੱਤ੍ਰੀ",
long:"ਕੁਰਿੰਥੀਆਂ ਨੂੰ ਦੂਜੀ ਪੱਤ੍ਰੀ",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ਗਲਾਤੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
long:"ਗਲਾਤੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"ਅਫ਼ਸੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
long:"ਅਫ਼ਸੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ਫ਼ਿਲਿੱਪੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
long:"ਫ਼ਿਲਿੱਪੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"ਕੁਲੁੱਸੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
long:"ਕੁਲੁੱਸੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"ਥੱਸਲੁਨੀਕੀਆਂ ਨੂੰ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
long:"ਥੱਸਲੁਨੀਕੀਆਂ ਨੂੰ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"ਥੱਸਲੁਨੀਕੀਆਂ ਨੂੰ ਦੂਜੀ ਪੱਤ੍ਰੀ",
long:"ਥੱਸਲੁਨੀਕੀਆਂ ਨੂੰ ਦੂਜੀ ਪੱਤ੍ਰੀ",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"ਤਿਮੋਥਿਉਸ ਨੂੰ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
long:"ਤਿਮੋਥਿਉਸ ਨੂੰ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"ਤਿਮੋਥਿਉਸ ਨੂੰ ਦੂਜੀ ਪੱਤ੍ਰੀ",
long:"ਤਿਮੋਥਿਉਸ ਨੂੰ ਦੂਜੀ ਪੱਤ੍ਰੀ",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"ਤੀਤੁਸ ਨੂੰ ਪੱਤ੍ਰੀ",
long:"ਤੀਤੁਸ ਨੂੰ ਪੱਤ੍ਰੀ",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ਫਿਲੇਮੋਨ ਨੂੰ ਪੱਤ੍ਰੀ",
long:"ਫਿਲੇਮੋਨ ਨੂੰ ਪੱਤ੍ਰੀ",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"ਇਬਰਾਨੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
long:"ਇਬਰਾਨੀਆਂ ਨੂੰ ਪੱਤ੍ਰੀ",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"ਯਾਕੂਬ ਦੀ ਪੱਤ੍ਰੀ",
long:"ਯਾਕੂਬ ਦੀ ਪੱਤ੍ਰੀ",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"ਪਤਰਸ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
long:"ਪਤਰਸ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"ਪਤਰਸ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ",
long:"ਪਤਰਸ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"ਯੂਹੰਨਾ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
long:"ਯੂਹੰਨਾ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"ਯੂਹੰਨਾ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ",
long:"ਯੂਹੰਨਾ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"ਯੂਹੰਨਾ ਦੀ ਤੀਜੀ ਪੱਤ੍ਰੀ",
long:"ਯੂਹੰਨਾ ਦੀ ਤੀਜੀ ਪੱਤ੍ਰੀ",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"ਯਹੂਦਾਹ ਦੀ ਪੱਤ੍ਰੀ",
long:"ਯਹੂਦਾਹ ਦੀ ਪੱਤ੍ਰੀ",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"ਯੂਹੰਨਾ ਦੇ ਪਰਕਾਸ਼ ਦੀ ਪੋਥੀ",
long:"ਯੂਹੰਨਾ ਦੇ ਪਰਕਾਸ਼ ਦੀ ਪੋਥੀ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
