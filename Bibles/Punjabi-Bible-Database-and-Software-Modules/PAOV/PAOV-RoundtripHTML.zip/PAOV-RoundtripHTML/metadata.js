biblename = "ਪਵਿੱਤਰ ਬਾਈਬਲ O.V. (BSI)";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"ਉਤਪਤ",
long:"ਉਤਪਤ",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"ਕੂਚ",
long:"ਕੂਚ",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"ਲੇਵੀਆਂ ਦੀ ਪੋਥੀ",
long:"ਲੇਵੀਆਂ ਦੀ ਪੋਥੀ",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"ਗਿਣਤੀ",
long:"ਗਿਣਤੀ",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"ਬਿਵਸਥਾਸਾਰ",
long:"ਬਿਵਸਥਾਸਾਰ",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"ਯਹੋਸ਼ੁਆ",
long:"ਯਹੋਸ਼ੁਆ",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"ਨਿਆਈਆਂ ਦੀ ਪੋਥੀ",
long:"ਨਿਆਈਆਂ ਦੀ ਪੋਥੀ",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"ਰੂਥ",
long:"ਰੂਥ",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"1 ਸਮੂਏਲ",
long:"1 ਸਮੂਏਲ",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"ਸਮੂਏਲ ਦੀ ਦੂਜੀ ਪੋਥੀ",
long:"ਸਮੂਏਲ ਦੀ ਦੂਜੀ ਪੋਥੀ",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"ਰਾਜਿਆਂ ਦੀ ਪਹਿਲੀ ਪੋਥੀ",
long:"ਰਾਜਿਆਂ ਦੀ ਪਹਿਲੀ ਪੋਥੀ",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"ਰਾਜਿਆਂ ਦੀ ਦੂਜੀ ਪੋਥੀ",
long:"ਰਾਜਿਆਂ ਦੀ ਦੂਜੀ ਪੋਥੀ",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"1 ਇਤਹਾਸ",
long:"1 ਇਤਹਾਸ",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"2 ਇਤਹਾਸ",
long:"2 ਇਤਹਾਸ",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"ਅਜ਼ਰਾ",
long:"ਅਜ਼ਰਾ",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"ਨਹਮਯਾਹ",
long:"ਨਹਮਯਾਹ",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"ਅਸਤਰ",
long:"ਅਸਤਰ",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"ਅੱਯੂਬ",
long:"ਅੱਯੂਬ",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"ਜ਼ਬੂਰਾਂ ਦੀ ਪੋਥੀ",
long:"ਜ਼ਬੂਰਾਂ ਦੀ ਪੋਥੀ",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"ਕਹਾਉਤਾਂ",
long:"ਕਹਾਉਤਾਂ",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"ਉਪਦੇਸ਼ਕ ਦੀ ਪੋਥੀ",
long:"ਉਪਦੇਸ਼ਕ ਦੀ ਪੋਥੀ",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"ਸਰੇਸ਼ਟ ਗੀਤ",
long:"ਸਰੇਸ਼ਟ ਗੀਤ",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"ਯਸਾਯਾਹ",
long:"ਯਸਾਯਾਹ",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"ਯਿਰਮਿਯਾਹ",
long:"ਯਿਰਮਿਯਾਹ",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"ਯਿਰਮਿਯਾਹ ਦਾ ਵਿਰਲਾਪ",
long:"ਯਿਰਮਿਯਾਹ ਦਾ ਵਿਰਲਾਪ",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"ਹਿਜ਼ਕੀਏਲ",
long:"ਹਿਜ਼ਕੀਏਲ",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"ਦਾਨੀਏਲ ਦੀ ਪੋਥੀ",
long:"ਦਾਨੀਏਲ ਦੀ ਪੋਥੀ",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"ਹੋਸ਼ੇਆ",
long:"ਹੋਸ਼ੇਆ",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"ਯੋਏਲ",
long:"ਯੋਏਲ",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"ਆਮੋਸ",
long:"ਆਮੋਸ",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"ਓਬਦਯਾਹ",
long:"ਓਬਦਯਾਹ",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"ਯੂਨਾਹ",
long:"ਯੂਨਾਹ",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"ਮੀਕਾਹ",
long:"ਮੀਕਾਹ",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"ਨਹੂਮ",
long:"ਨਹੂਮ",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"ਹਬੱਕੂਕ",
long:"ਹਬੱਕੂਕ",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"ਸਫ਼ਨਯਾਹ",
long:"ਸਫ਼ਨਯਾਹ",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"ਹੱਜਈ",
long:"ਹੱਜਈ",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"ਜ਼ਕਰਯਾਹ",
long:"ਜ਼ਕਰਯਾਹ",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"ਮਲਾਕੀ",
long:"ਮਲਾਕੀ",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"ਮੱਤੀ ਦੀ ਇੰਜੀਲ",
long:"ਮੱਤੀ ਦੀ ਇੰਜੀਲ",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"ਮਰਕੁਸ ਦੀ ਇੰਜੀਲ",
long:"ਮਰਕੁਸ ਦੀ ਇੰਜੀਲ",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ਲੂਕਾ ਦੀ ਇੰਜੀਲ",
long:"ਲੂਕਾ ਦੀ ਇੰਜੀਲ",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"ਯੂਹੰਨਾ ਦੀ ਇੰਜੀਲ",
long:"ਯੂਹੰਨਾ ਦੀ ਇੰਜੀਲ",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"ਰਸੂਲਾਂ ਦੇ ਕਰਤੱਬ",
long:"ਰਸੂਲਾਂ ਦੇ ਕਰਤੱਬ",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਰੋਮੀਆਂ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਰੋਮੀਆਂ ਨੂੰ",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ ਕੁਰਿੰਥੀਆਂ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ ਕੁਰਿੰਥੀਆਂ ਨੂੰ",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ ਕੁਰਿੰਥੀਆਂ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ ਕੁਰਿੰਥੀਆਂ ਨੂੰ",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਗਲਾਤੀਆਂ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਗਲਾਤੀਆਂ ਨੂੰ",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਅਫ਼ਸੀਆਂ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਅਫ਼ਸੀਆਂ ਨੂੰ",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਫ਼ਿਲਿੱਪੀਆਂ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਫ਼ਿਲਿੱਪੀਆਂ ਨੂੰ",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਕੁਲੁੱਸੀਆਂ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਕੁਲੁੱਸੀਆਂ ਨੂੰ",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ ਥੱਸਲੁਨੀਕੀਆਂ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ ਥੱਸਲੁਨੀਕੀਆਂ ਨੂੰ",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ ਥੱਸਲੁਨੀਕੀਆਂ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ ਥੱਸਲੁਨੀਕੀਆਂ",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ ਤਿਮੋਥਿਉਸ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ ਤਿਮੋਥਿਉਸ ਨੂੰ",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ ਤਿਮੋਥਿਉਸ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ ਤਿਮੋਥਿਉਸ ਨੂੰ",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਤੀਤੁਸ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਤੀਤੁਸ ਨੂੰ",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਫਿਲੇਮੋਨ ਨੂੰ",
long:"ਪੌਲੁਸ ਰਸੂਲ ਦੀ ਪੱਤ੍ਰੀ ਫਿਲੇਮੋਨ ਨੂੰ",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"ਇਬਰਾਨੀਆਂ ਨੂੰ",
long:"ਇਬਰਾਨੀਆਂ ਨੂੰ",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"ਯਾਕੂਬ ਦੀ ਪੱਤ੍ਰੀ",
long:"ਯਾਕੂਬ ਦੀ ਪੱਤ੍ਰੀ",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"ਪਤਰਸ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
long:"ਪਤਰਸ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"ਪਤਰਸ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ",
long:"ਪਤਰਸ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"ਯੂਹੰਨਾ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
long:"ਯੂਹੰਨਾ ਦੀ ਪਹਿਲੀ ਪੱਤ੍ਰੀ",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"ਯੂਹੰਨਾ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ",
long:"ਯੂਹੰਨਾ ਦੀ ਦੂਜੀ ਪੱਤ੍ਰੀ",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"ਯੂਹੰਨਾ ਦੀ ਤੀਜੀ ਪੱਤ੍ਰੀ",
long:"ਯੂਹੰਨਾ ਦੀ ਤੀਜੀ ਪੱਤ੍ਰੀ",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"ਯਹੂਦਾਹ ਦੀ ਪੱਤ੍ਰੀ",
long:"ਯਹੂਦਾਹ ਦੀ ਪੱਤ੍ਰੀ",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"ਯੂਹੰਨਾ ਦੇ ਪਰਕਾਸ਼ ਦੀ ਪੋਥੀ",
long:"ਯੂਹੰਨਾ ਦੇ ਪਰਕਾਸ਼ ਦੀ ਪੋਥੀ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
