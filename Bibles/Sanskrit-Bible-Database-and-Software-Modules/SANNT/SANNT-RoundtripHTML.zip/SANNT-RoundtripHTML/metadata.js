biblename = "Sanskrit New Testament - BSI";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Mt",
short:"साधोः मत्तिनः अनुसारं शुभः समाचारः",
long:"साधोः मत्तिनः अनुसारं शुभः समाचारः",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mk",
short:"साधोः मारकुसस्‍य (मरकुसस्‍य) अनुसारं शुभसमाचारः",
long:"साधोः मारकुसस्‍य (मरकुसस्‍य) अनुसारं शुभसमाचारः",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Lk",
short:"साधोः लूकसस्‍य (लूकस्‍य) अनुसारं शुभः समाचारः",
long:"साधोः लूकसस्‍य (लूकस्‍य) अनुसारं शुभः समाचारः",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"Jn",
short:"साधोः योहनस्‍य (यूहन्‍नः) अनुसारं शुभः समाचारः",
long:"साधोः योहनस्‍य (यूहन्‍नः) अनुसारं शुभः समाचारः",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"प्रेरिताणाम्‌ कार्यकलापः",
long:"प्रेरिताणाम्‌ कार्यकलापः",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"रोमनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
long:"रोमनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"कुरिन्‍थुसनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य प्रथमपत्रम्‌",
long:"कुरिन्‍थुसनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य प्रथमपत्रम्‌",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"कुरिन्‍थुसनगरस्‍य कलीसियायाः नाम साधोः पौलुसस्‍य द्वितीयम्‌ पत्रम्‌",
long:"कुरिन्‍थुसनगरस्‍य कलीसियायाः नाम साधोः पौलुसस्‍य द्वितीयम्‌ पत्रम्‌",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"गलातियाप्रदेशस्‍य कलीसियानाम्‌ नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
long:"गलातियाप्रदेशस्‍य कलीसियानाम्‌ नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"इफिसुसनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
long:"इफिसुसनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"फिलिप्‍पीनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
long:"फिलिप्‍पीनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"कुलुस्‍सेनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
long:"कुलुस्‍सेनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Ths",
short:"थिस्‍सलुनीकेनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य प्रथमं पत्रम्‌",
long:"थिस्‍सलुनीकेनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य प्रथमं पत्रम्‌",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Ths",
short:"थिस्‍सलुनीकेनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य द्वितीयम्‌ पत्रम्‌",
long:"थिस्‍सलुनीकेनगरस्‍य कलीसियायाः नाम्‍नि साधोः पौलुसस्‍य द्वितीयम्‌ पत्रम्‌",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"तिमोथिनः नाम्‍नि साधोः पौलुसस्‍य पथमपत्रम्‌",
long:"तिमोथिनः नाम्‍नि साधोः पौलुसस्‍य पथमपत्रम्‌",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"तिमोथिनः नाम्‍नि साधोः पौलुसस्‍य द्वितीयम्‌ पत्रम्‌",
long:"तिमोथिनः नाम्‍नि साधोः पौलुसस्‍य द्वितीयम्‌ पत्रम्‌",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"तीतुसस्‍य नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
long:"तीतुसस्‍य नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"फिलेमोनस्‍य नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
long:"फिलेमोनस्‍य नाम्‍नि साधोः पौलुसस्‍य पत्रम्‌",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"इब्राणिनाम्‌ नाम्‍नि पत्रम्‌",
long:"इब्राणिनाम्‌ नाम्‍नि पत्रम्‌",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"साधोः याकूबस्‍य पत्रम्‌",
long:"साधोः याकूबस्‍य पत्रम्‌",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"साधोः पतरसस्‍य प्रथम पत्रम्‌",
long:"साधोः पतरसस्‍य प्रथम पत्रम्‌",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"साधोः पतरसस्‍य द्वितीयम्‌ पत्रम्‌",
long:"साधोः पतरसस्‍य द्वितीयम्‌ पत्रम्‌",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Jn",
short:"साधोः योहनस्‍य प्रथमपत्रम्‌",
long:"साधोः योहनस्‍य प्रथमपत्रम्‌",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Jn",
short:"साधोः योहनस्‍य द्वितीयम्‌ पत्रम्‌",
long:"साधोः योहनस्‍य द्वितीयम्‌ पत्रम्‌",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3Jn",
short:"साधोः योहनस्‍य तृतीय पत्रम्‌",
long:"साधोः योहनस्‍य तृतीय पत्रम्‌",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"साधोः यूदसस्‍य पत्रम्‌",
long:"साधोः यूदसस्‍य पत्रम्‌",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"प्रकाशनाग्रन्‍थः",
long:"प्रकाशनाग्रन्‍थः",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
