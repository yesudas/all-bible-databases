biblename = "Sinhala New Revised Version";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Intro",
short:"_Introduction_",
long:"_Introduction_",
osis:"x-Intr",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"උත්පත්ති",
long:"උත්පත්ති",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"නික්මයාම",
long:"නික්මයාම",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"ලෙවී ව්‍යවස්ථාව",
long:"ලෙවී ව්‍යවස්ථාව",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"ගණන් කථාව",
long:"ගණන් කථාව",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"ද්විතීය නීති සංග්‍රහය",
long:"ද්විතීය නීති සංග්‍රහය",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"ජෝෂු",
long:"ජෝෂු",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"වීරාවලිය",
long:"වීරාවලිය",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"රූත්",
long:"රූත්",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"1 සාමුවෙල්",
long:"1 සාමුවෙල්",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"2 සාමුවෙල්",
long:"2 සාමුවෙල්",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"1 රාජාවලියේ",
long:"1 රාජාවලියේ",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"2 රාජාවලියේ",
long:"2 රාජාවලියේ",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"1 වංශාවලියේ",
long:"1 වංශාවලියේ",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"2 වංශාවලියේ",
long:"2 වංශාවලියේ",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"එස්රා",
long:"එස්රා",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"නෙහෙමියා",
long:"නෙහෙමියා",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"එස්තර්",
long:"එස්තර්",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"ජෝබ්",
long:"ජෝබ්",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"ගීතාවලිය",
long:"ගීතාවලිය",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"හිතෝපදේශ",
long:"හිතෝපදේශ",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"ධර්මදේශකයා",
long:"ධර්මදේශකයා",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"ප්‍රේම ගී",
long:"ප්‍රේම ගී",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"යෙසායා",
long:"යෙසායා",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"ජෙරමියා",
long:"ජෙරමියා",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"විලාප ගී",
long:"විලාප ගී",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"එසකියෙල්ගේ",
long:"එසකියෙල්ගේ",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"දානියෙල්",
long:"දානියෙල්",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"හොසියා",
long:"හොසියා",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"ජෝවෙල්",
long:"ජෝවෙල්",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"අාමොස්",
long:"අාමොස්",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"ඔබදියා",
long:"ඔබදියා",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"ජෝනා",
long:"ජෝනා",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"මීකා",
long:"මීකා",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"නාහුම්",
long:"නාහුම්",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"හබක්කුක්",
long:"හබක්කුක්",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"ශෙපනියා",
long:"ශෙපනියා",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"හග්ගයි",
long:"හග්ගයි",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"සෙකරියා",
long:"සෙකරියා",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"මලාකි",
long:"මලාකි",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"ශුද්ධවර මතෙව්",
long:"ශුද්ධවර මතෙව්",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"ශුද්ධවර මාක්",
long:"ශුද්ධවර මාක්",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"ශුද්ධවර ලූක්",
long:"ශුද්ධවර ලූක්",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"ශුද්ධවර ජොහන්",
long:"ශුද්ධවර ජොහන්",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"ක්‍රියා",
long:"ක්‍රියා",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"රෝම",
long:"රෝම",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"1 කොරින්ති",
long:"1 කොරින්ති",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"2 කොරින්ති",
long:"2 කොරින්ති",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"ගලාති",
long:"ගලාති",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"එපීස ‍",
long:"එපීස ‍",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"පිලිප්පි",
long:"පිලිප්පි",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"කොලොස්සි",
long:"කොලොස්සි",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"1 තෙසලෝනික",
long:"1 තෙසලෝනික",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"2 තෙසලෝනික",
long:"2 තෙසලෝනික",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"1 තිමෝති",
long:"1 තිමෝති",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"2 තිමෝති",
long:"2 තිමෝති",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"තීතස්",
long:"තීතස්",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"පිලෙමොන්",
long:"පිලෙමොන්",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"හෙබ්‍රෙව්",
long:"හෙබ්‍රෙව්",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"ජාකොබ්",
long:"ජාකොබ්",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"1 පේදුරු",
long:"1 පේදුරු",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"2 පේදුරු",
long:"2 පේදුරු",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"1 ජොහන්",
long:"1 ජොහන්",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"2 ජොහන්",
long:"2 ජොහන්",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"3 ජොහන්",
long:"3 ජොහන්",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"ජූද්",
long:"ජූද්",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"එළිදරව්ව",
long:"එළිදරව්ව",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
