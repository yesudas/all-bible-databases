biblename = "திருவிவிலியம், Tamil Bible: Easy-to-Read Version";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Gen",
short:"தொடக்க நூல்",
long:"தொடக்க நூல்",
osis:"Gen",
type:"ot",
nt:false,
chapters:50
},{
abbr:"Exod",
short:"விடுதலைப் பயணம்",
long:"விடுதலைப் பயணம்",
osis:"Exod",
type:"ot",
nt:false,
chapters:40
},{
abbr:"Lev",
short:"லேவியர்",
long:"லேவியர்",
osis:"Lev",
type:"ot",
nt:false,
chapters:27
},{
abbr:"Num",
short:"எண்ணிக்கை",
long:"எண்ணிக்கை",
osis:"Num",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Deut",
short:"இணைச் சட்டம்",
long:"இணைச் சட்டம்",
osis:"Deut",
type:"ot",
nt:false,
chapters:34
},{
abbr:"Josh",
short:"யோசுவா",
long:"யோசுவா",
osis:"Josh",
type:"ot",
nt:false,
chapters:24
},{
abbr:"Judg",
short:"நீதித் தலைவர்கள்",
long:"நீதித் தலைவர்கள்",
osis:"Judg",
type:"ot",
nt:false,
chapters:21
},{
abbr:"Ruth",
short:"ரூத்து",
long:"ரூத்து",
osis:"Ruth",
type:"ot",
nt:false,
chapters:4
},{
abbr:"1Sam",
short:"1 சாமுவேல்",
long:"1 சாமுவேல்",
osis:"1Sam",
type:"ot",
nt:false,
chapters:31
},{
abbr:"2Sam",
short:"2 சாமுவேல்",
long:"2 சாமுவேல்",
osis:"2Sam",
type:"ot",
nt:false,
chapters:24
},{
abbr:"1Kgs",
short:"1 அரசர்கள்",
long:"1 அரசர்கள்",
osis:"1Kgs",
type:"ot",
nt:false,
chapters:22
},{
abbr:"2Kgs",
short:"2 அரசர்கள்",
long:"2 அரசர்கள்",
osis:"2Kgs",
type:"ot",
nt:false,
chapters:25
},{
abbr:"1Chr",
short:"1 குறிப்பேடு",
long:"1 குறிப்பேடு",
osis:"1Chr",
type:"ot",
nt:false,
chapters:29
},{
abbr:"2Chr",
short:"2 குறிப்பேடு",
long:"2 குறிப்பேடு",
osis:"2Chr",
type:"ot",
nt:false,
chapters:36
},{
abbr:"Ezra",
short:"எஸ்ரா",
long:"எஸ்ரா",
osis:"Ezra",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Neh",
short:"நெகேமியா",
long:"நெகேமியா",
osis:"Neh",
type:"ot",
nt:false,
chapters:13
},{
abbr:"Esth",
short:"எஸ்தர்",
long:"எஸ்தர்",
osis:"Esth",
type:"ot",
nt:false,
chapters:10
},{
abbr:"Job",
short:"யோபு",
long:"யோபு",
osis:"Job",
type:"ot",
nt:false,
chapters:42
},{
abbr:"Ps",
short:"திருப்பாடல்கள்",
long:"திருப்பாடல்கள்",
osis:"Ps",
type:"ot",
nt:false,
chapters:150
},{
abbr:"Prov",
short:"நீதிமொழிகள்",
long:"நீதிமொழிகள்",
osis:"Prov",
type:"ot",
nt:false,
chapters:31
},{
abbr:"Eccl",
short:"சபை உரையாளர்",
long:"சபை உரையாளர்",
osis:"Eccl",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Song",
short:"இனிமைமிகு பாடல்",
long:"இனிமைமிகு பாடல்",
osis:"Song",
type:"ot",
nt:false,
chapters:8
},{
abbr:"Isa",
short:"எசாயா",
long:"எசாயா",
osis:"Isa",
type:"ot",
nt:false,
chapters:66
},{
abbr:"Jer",
short:"எரேமியா",
long:"எரேமியா",
osis:"Jer",
type:"ot",
nt:false,
chapters:52
},{
abbr:"Lam",
short:"புலம்பல்",
long:"புலம்பல்",
osis:"Lam",
type:"ot",
nt:false,
chapters:5
},{
abbr:"Ezek",
short:"எசேக்கியேல்",
long:"எசேக்கியேல்",
osis:"Ezek",
type:"ot",
nt:false,
chapters:48
},{
abbr:"Dan",
short:"தானியேல்",
long:"தானியேல்",
osis:"Dan",
type:"ot",
nt:false,
chapters:12
},{
abbr:"Hos",
short:"ஓசேயா",
long:"ஓசேயா",
osis:"Hos",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Joel",
short:"யோவேல்",
long:"யோவேல்",
osis:"Joel",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Amos",
short:"ஆமோஸ்",
long:"ஆமோஸ்",
osis:"Amos",
type:"ot",
nt:false,
chapters:9
},{
abbr:"Obad",
short:"ஒபதியா",
long:"ஒபதியா",
osis:"Obad",
type:"ot",
nt:false,
chapters:1
},{
abbr:"Jonah",
short:"யோனா",
long:"யோனா",
osis:"Jonah",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Mic",
short:"மீக்கா",
long:"மீக்கா",
osis:"Mic",
type:"ot",
nt:false,
chapters:7
},{
abbr:"Nah",
short:"நாகூம்",
long:"நாகூம்",
osis:"Nah",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hab",
short:"அபக்கூக்கு",
long:"அபக்கூக்கு",
osis:"Hab",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Zeph",
short:"செப்பனியா",
long:"செப்பனியா",
osis:"Zeph",
type:"ot",
nt:false,
chapters:3
},{
abbr:"Hag",
short:"ஆகாய்",
long:"ஆகாய்",
osis:"Hag",
type:"ot",
nt:false,
chapters:2
},{
abbr:"Zech",
short:"செக்கரியா",
long:"செக்கரியா",
osis:"Zech",
type:"ot",
nt:false,
chapters:14
},{
abbr:"Mal",
short:"மலாக்கி",
long:"மலாக்கி",
osis:"Mal",
type:"ot",
nt:false,
chapters:4
},{
abbr:"Matt",
short:"மத்தேயு நற்செய்தியை",
long:"மத்தேயு நற்செய்தியை",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"மாற்கு நற்செய்தியை",
long:"மாற்கு நற்செய்தியை",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"லூக்கா நற்செய்தியை",
long:"லூக்கா நற்செய்தியை",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"யோவான் நற்செய்தியை",
long:"யோவான் நற்செய்தியை",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"திருத்தூதர் பணிகள்",
long:"திருத்தூதர் பணிகள்",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"உரோமையருக்கு எழுதிய திருமுகம்",
long:"உரோமையருக்கு எழுதிய திருமுகம்",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"கொரிந்தியருக்கு எழுதிய முதல் திருமுகம்",
long:"கொரிந்தியருக்கு எழுதிய முதல் திருமுகம்",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"கொரிந்தியருக்கு எழுதிய இரண்டாம் திருமுகம்",
long:"கொரிந்தியருக்கு எழுதிய இரண்டாம் திருமுகம்",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"கலாத்தியருக்கு எழுதிய திருமுகம்",
long:"கலாத்தியருக்கு எழுதிய திருமுகம்",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"எபேசியருக்கு எழுதிய திருமுகம்",
long:"எபேசியருக்கு எழுதிய திருமுகம்",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"பிலிப்பியருக்கு எழுதிய திருமுகம்",
long:"பிலிப்பியருக்கு எழுதிய திருமுகம்",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"கொலோசையருக்கு எழுதிய திருமுகம்",
long:"கொலோசையருக்கு எழுதிய திருமுகம்",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"தெசலோனிக்கருக்கு எழுதிய முதல் திருமுகம்",
long:"தெசலோனிக்கருக்கு எழுதிய முதல் திருமுகம்",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"தெசலோனிக்கருக்கு எழுதிய இரண்டாம் திருமுகம்",
long:"தெசலோனிக்கருக்கு எழுதிய இரண்டாம் திருமுகம்",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"திமொத்தேயுவுக்கு எழுதிய முதல் திருமுகம்",
long:"திமொத்தேயுவுக்கு எழுதிய முதல் திருமுகம்",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"திமொத்தேயுவுக்கு எழுதிய இரண்டாம் திருமுகம்",
long:"திமொத்தேயுவுக்கு எழுதிய இரண்டாம் திருமுகம்",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"தீத்துவுக்கு எழுதிய திருமுகம்",
long:"தீத்துவுக்கு எழுதிய திருமுகம்",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"பிலமோனுக்கு எழுதிய திருமுகம்",
long:"பிலமோனுக்கு எழுதிய திருமுகம்",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"எபிஎபிரேயருக்கு எழுதிய திருமுகம்",
long:"எபிஎபிரேயருக்கு எழுதிய திருமுகம்",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"யாக்கோபுஎழுதிய திருமுகம்",
long:"யாக்கோபுஎழுதிய திருமுகம்",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"பேதுரு எழுதிய முதல் திருமுகம்",
long:"பேதுரு எழுதிய முதல் திருமுகம்",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"பேதுரு எழுதிய இரண்டாம் திருமுகம்",
long:"பேதுரு எழுதிய இரண்டாம் திருமுகம்",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"யோவான் எழுதிய முதல் திருமுகம்",
long:"யோவான் எழுதிய முதல் திருமுகம்",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"யோவான் எழுதிய இரண்டாம் திருமுகம்",
long:"யோவான் எழுதிய இரண்டாம் திருமுகம்",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"யோவான் எழுதிய முன்றாம் திருமுகம்",
long:"யோவான் எழுதிய முன்றாம் திருமுகம்",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"யூதா எழுதிய திருமுகம்",
long:"யூதா எழுதிய திருமுகம்",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"யோவானுக்கு அருளப்பெற்ற திருவெளிப்பாடு",
long:"யோவானுக்கு அருளப்பெற்ற திருவெளிப்பாடு",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
