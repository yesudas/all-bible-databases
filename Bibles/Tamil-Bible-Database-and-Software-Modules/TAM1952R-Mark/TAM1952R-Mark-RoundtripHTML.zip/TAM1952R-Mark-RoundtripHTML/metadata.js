biblename = "Imported From theWord";
metadata = [{
abbr:"Mark",
short:"Mark",
long:"Mark",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"Luke",
long:"Luke",
osis:"Luke",
type:"nt",
nt:true,
chapters:1
}];
