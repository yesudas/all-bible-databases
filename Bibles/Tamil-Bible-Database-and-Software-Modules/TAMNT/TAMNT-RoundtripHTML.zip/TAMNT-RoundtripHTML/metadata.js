biblename = "Tamil New Testament, 2017";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Intro",
short:"_Introduction_",
long:"_Introduction_",
osis:"x-Intr",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"மத்தேயு",
long:"மத்தேயு",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"மாற்கு",
long:"மாற்கு",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"லூக்கா",
long:"லூக்கா",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"யோவான்",
long:"யோவான்",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"அப்போஸ்தலர்",
long:"அப்போஸ்தலர்",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"ரோமர்",
long:"ரோமர்",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"1 கொரிந்தியர்",
long:"1 கொரிந்தியர்",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"2 கொரிந்தியர்",
long:"2 கொரிந்தியர்",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"கலாத்தியர்",
long:"கலாத்தியர்",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"எபேசியர்",
long:"எபேசியர்",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"பிலிப்பியர்",
long:"பிலிப்பியர்",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"கொலோசெயர்",
long:"கொலோசெயர்",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"1 தெசலோனிக்கேயர்",
long:"1 தெசலோனிக்கேயர்",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"2 தெசலோனிக்கேயர்",
long:"2 தெசலோனிக்கேயர்",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"1 தீமோத்தேயு",
long:"1 தீமோத்தேயு",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"2 தீமோத்தேயு",
long:"2 தீமோத்தேயு",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"தீத்து",
long:"தீத்து",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"பிலேமோன்",
long:"பிலேமோன்",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"எபிரேயர்",
long:"எபிரேயர்",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"யாக்கோபு",
long:"யாக்கோபு",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"1 பேதுரு",
long:"1 பேதுரு",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"2 பேதுரு",
long:"2 பேதுரு",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"1 யோவான்",
long:"1 யோவான்",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"2 யோவான்",
long:"2 யோவான்",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"3 யோவான்",
long:"3 யோவான்",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"யூதா",
long:"யூதா",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"வெளிப்படுத்தின விசேஷம்",
long:"வெளிப்படுத்தின விசேஷம்",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
