biblename = "Imported From theWord";
metadata = [{
abbr:"Matt",
short:"Matthew",
long:"Matthew",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"Mark",
long:"Mark",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"Luke",
long:"Luke",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"John",
long:"John",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"Acts",
long:"Acts",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"Romans",
long:"Romans",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"1 Corinthians",
long:"1 Corinthians",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"2 Corinthians",
long:"2 Corinthians",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"Galatians",
long:"Galatians",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"Ephesians",
long:"Ephesians",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"Philippians",
long:"Philippians",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"Colossians",
long:"Colossians",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"1 Thessalonians",
long:"1 Thessalonians",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"2 Thessalonians",
long:"2 Thessalonians",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"1 Timothy",
long:"1 Timothy",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"2 Timothy",
long:"2 Timothy",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"Titus",
long:"Titus",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"Philemon",
long:"Philemon",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"Hebrews",
long:"Hebrews",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"James",
long:"James",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"1 Peter",
long:"1 Peter",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"2 Peter",
long:"2 Peter",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"1 John",
long:"1 John",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2John",
short:"2 John",
long:"2 John",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3John",
short:"3 John",
long:"3 John",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jude",
short:"Jude",
long:"Jude",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"Revelation",
long:"Revelation",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
