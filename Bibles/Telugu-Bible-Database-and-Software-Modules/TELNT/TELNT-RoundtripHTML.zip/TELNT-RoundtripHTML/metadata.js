biblename = "తెలుగు బైబిల్";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Mat",
short:"మత్తయి సువార్త",
long:"మత్తయి సువార్త",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mar",
short:"మార్కు సువార్త",
long:"మార్కు సువార్త",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luk",
short:"లూకా సువార్త",
long:"లూకా సువార్త",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"యోహాను సువార్త",
long:"యోహాను సువార్త",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"అపొస్తలుల కార్యములు",
long:"అపొస్తలుల కార్యములు",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"రోమీయులకు",
long:"రోమీయులకు",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"1 కొరింథీయులకు",
long:"1 కొరింథీయులకు",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"2 కొరింథీయులకు",
long:"2 కొరింథీయులకు",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"గలతీయులకు",
long:"గలతీయులకు",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"ఎఫెసీయులకు",
long:"ఎఫెసీయులకు",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"ఫిలిప్పీయులకు",
long:"ఫిలిప్పీయులకు",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Col",
short:"కొలొస్సయులకు",
long:"కొలొస్సయులకు",
osis:"Col",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Ths",
short:"1 థెస్సలొనీకయులకు",
long:"1 థెస్సలొనీకయులకు",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Ths",
short:"2 థెస్సలొనీకయులకు",
long:"2 థెస్సలొనీకయులకు",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"1 తిమోతికి",
long:"1 తిమోతికి",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"2 తిమోతికి",
long:"2 తిమోతికి",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Tit",
short:"తీతుకు",
long:"తీతుకు",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"ఫిలేమోనుకు",
long:"ఫిలేమోనుకు",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"హెబ్రీయులకు",
long:"హెబ్రీయులకు",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jam",
short:"యాకోబు",
long:"యాకోబు",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"1 పేతురు",
long:"1 పేతురు",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"2 పేతురు",
long:"2 పేతురు",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Jn",
short:"1 యోహాను",
long:"1 యోహాను",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Jn",
short:"2 యోహాను",
long:"2 యోహాను",
osis:"2John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"3Jn",
short:"3 యోహాను",
long:"3 యోహాను",
osis:"3John",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Jud",
short:"యూదా",
long:"యూదా",
osis:"Jude",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Rev",
short:"ప్రకటన గ్రంథము",
long:"ప్రకటన గ్రంథము",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
