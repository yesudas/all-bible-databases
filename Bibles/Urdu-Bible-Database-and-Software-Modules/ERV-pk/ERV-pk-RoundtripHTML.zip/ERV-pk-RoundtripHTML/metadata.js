biblename = "Urdu New Testament: Easy-to-Read Version";
metadata = [{
abbr:"Metadata",
short:"Metadata",
long:"Metadata",
osis:"x-Meta",
type:"meta",
nt:false,
chapters:1
},{
abbr:"Matt",
short:"متی کی انجیل",
long:"متی کی انجیل",
osis:"Matt",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Mark",
short:"مرقس کی انجیل",
long:"مرقس کی انجیل",
osis:"Mark",
type:"nt",
nt:true,
chapters:16
},{
abbr:"Luke",
short:"لوقا کی انجیل",
long:"لوقا کی انجیل",
osis:"Luke",
type:"nt",
nt:true,
chapters:24
},{
abbr:"John",
short:"یوحنا کی انجیل",
long:"یوحنا کی انجیل",
osis:"John",
type:"nt",
nt:true,
chapters:21
},{
abbr:"Acts",
short:"یوحنا کے اعمال",
long:"یوحنا کے اعمال",
osis:"Acts",
type:"nt",
nt:true,
chapters:28
},{
abbr:"Rom",
short:"رومیوں کے نام کا خط",
long:"رومیوں کے نام کا خط",
osis:"Rom",
type:"nt",
nt:true,
chapters:16
},{
abbr:"1Cor",
short:"کرنتھیوں کے نام کا پہلا خط",
long:"کرنتھیوں کے نام کا پہلا خط",
osis:"1Cor",
type:"nt",
nt:true,
chapters:16
},{
abbr:"2Cor",
short:"کرنتھیوں کے نام کا دوسرا خط",
long:"کرنتھیوں کے نام کا دوسرا خط",
osis:"2Cor",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Gal",
short:"گلتیوں کے نام کا خط",
long:"گلتیوں کے نام کا خط",
osis:"Gal",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Eph",
short:"افسیوں کے نام کا خط",
long:"افسیوں کے نام کا خط",
osis:"Eph",
type:"nt",
nt:true,
chapters:6
},{
abbr:"Phil",
short:"فلپیوں کے نام کا خط",
long:"فلپیوں کے نام کا خط",
osis:"Phil",
type:"nt",
nt:true,
chapters:4
},{
abbr:"1Thess",
short:"تھسلنیکیوں کے نام کا پہلا خط",
long:"تھسلنیکیوں کے نام کا پہلا خط",
osis:"1Thess",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Thess",
short:"تھسلنیکیوں کے نام کا دوسرا خط",
long:"تھسلنیکیوں کے نام کا دوسرا خط",
osis:"2Thess",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1Tim",
short:"تیمتھیس کے نام کا پہلا خط",
long:"تیمتھیس کے نام کا پہلا خط",
osis:"1Tim",
type:"nt",
nt:true,
chapters:6
},{
abbr:"2Tim",
short:"تیمتھیس کے نام کا دوسرا خط",
long:"تیمتھیس کے نام کا دوسرا خط",
osis:"2Tim",
type:"nt",
nt:true,
chapters:4
},{
abbr:"Titus",
short:"ططس کے نام کا خط",
long:"ططس کے نام کا خط",
osis:"Titus",
type:"nt",
nt:true,
chapters:3
},{
abbr:"Phlm",
short:"فلیمون کے نام کا خط",
long:"فلیمون کے نام کا خط",
osis:"Phlm",
type:"nt",
nt:true,
chapters:1
},{
abbr:"Heb",
short:"عبرانیوں کے نام کا خط",
long:"عبرانیوں کے نام کا خط",
osis:"Heb",
type:"nt",
nt:true,
chapters:13
},{
abbr:"Jas",
short:"یعقوب کا عام خط",
long:"یعقوب کا عام خط",
osis:"Jas",
type:"nt",
nt:true,
chapters:5
},{
abbr:"1Pet",
short:"پطرس کا پہلا عام خط",
long:"پطرس کا پہلا عام خط",
osis:"1Pet",
type:"nt",
nt:true,
chapters:5
},{
abbr:"2Pet",
short:"پطرس کا دوسرا عام خط",
long:"پطرس کا دوسرا عام خط",
osis:"2Pet",
type:"nt",
nt:true,
chapters:3
},{
abbr:"1John",
short:"یوحنا کا پہلا عام خط",
long:"یوحنا کا پہلا عام خط",
osis:"1John",
type:"nt",
nt:true,
chapters:5
},{
abbr:"Rev",
short:"یو حنا عارف کا مکاشفہ",
long:"یو حنا عارف کا مکاشفہ",
osis:"Rev",
type:"nt",
nt:true,
chapters:22
}];
